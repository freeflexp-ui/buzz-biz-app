package com.buzzbiz.app

data class CsvRow(
  val name: String,
  val category: String,
  val price: Double?,
  val stock: Long?,
)

private fun splitCsv(text: String, delimiter: Char): List<List<String>> {
  val rows = ArrayList<List<String>>()
  var row = ArrayList<String>()
  val cell = StringBuilder()
  var inQuotes = false
  var i = 0
  while (i < text.length) {
    val c = text[i]
    if (inQuotes) {
      if (c == '"') {
        if (i + 1 < text.length && text[i + 1] == '"') {
          cell.append('"')
          i++
        } else {
          inQuotes = false
        }
      } else {
        cell.append(c)
      }
    } else {
      when (c) {
        '"' -> inQuotes = true
        delimiter -> {
          row.add(cell.toString())
          cell.setLength(0)
        }
        '\n' -> {
          row.add(cell.toString())
          cell.setLength(0)
          rows.add(row)
          row = ArrayList()
        }
        '\r' -> {
        }
        else -> cell.append(c)
      }
    }
    i++
  }
  if (cell.isNotEmpty() || row.isNotEmpty()) {
    row.add(cell.toString())
    rows.add(row)
  }
  return rows
}

private fun indexOfHeader(header: List<String>, names: List<String>): Int =
  header.indexOfFirst { h -> names.contains(h) }

fun parseItemsCsv(raw: String, maxRows: Int = 3000): List<CsvRow> {
  val text = raw.removePrefix("\uFEFF")
  if (text.isBlank()) return emptyList()
  val firstLine = text.lineSequence().firstOrNull() ?: ""
  val delimiter = listOf(',', ';', '\t')
    .maxByOrNull { d -> firstLine.count { it == d } }
    ?.takeIf { firstLine.contains(it) } ?: ','
  val table = splitCsv(text, delimiter).filter { r -> r.any { it.isNotBlank() } }
  if (table.isEmpty()) return emptyList()

  val header = table[0].map { it.trim().lowercase() }
  var nameIdx = indexOfHeader(header, listOf("name", "item", "item name", "product", "product name", "description"))
  val hasHeader = nameIdx >= 0
  var catIdx = indexOfHeader(header, listOf("category", "section", "group", "type", "department"))
  var priceIdx = indexOfHeader(header, listOf("price", "selling price", "unit price"))
  var stockIdx = indexOfHeader(header, listOf("stock", "quantity", "qty", "opening stock", "in stock"))
  if (!hasHeader) {
    nameIdx = 0
    catIdx = if (header.size > 1) 1 else -1
    priceIdx = if (header.size > 2) 2 else -1
    stockIdx = if (header.size > 3) 3 else -1
  }

  fun cellAt(r: List<String>, i: Int): String = if (i >= 0 && i < r.size) r[i].trim() else ""

  val rows = ArrayList<CsvRow>()
  val body = if (hasHeader) table.drop(1) else table
  for (r in body) {
    val name = cellAt(r, nameIdx)
    if (name.isEmpty()) continue
    val price = cellAt(r, priceIdx).replace(Regex("[^0-9.]"), "").toDoubleOrNull()
    val stock = cellAt(r, stockIdx).replace(Regex("[^0-9.]"), "").toDoubleOrNull()?.toLong()
    rows.add(CsvRow(name, cellAt(r, catIdx), price, stock))
    if (rows.size >= maxRows) break
  }
  return rows
}
