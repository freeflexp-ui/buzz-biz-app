package com.buzzbiz.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.height
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.VisualTransformation
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.WriteBatch
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// ---------------------------------------------------------------- helpers

fun todayString(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

fun shiftDate(date: String, delta: Int): String {
  val cal = Calendar.getInstance()
  val parsed = try {
    SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)
  } catch (e: Exception) {
    null
  }
  if (parsed != null) cal.time = parsed
  cal.add(Calendar.DAY_OF_YEAR, delta)
  return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
}

private fun parseDate(s: String): Date? = try {
  SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)
} catch (e: Exception) {
  null
}

private fun fmtDate(d: Date): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)

fun periodRange(period: String, anchor: String): Pair<String, String> {
  val cal = Calendar.getInstance()
  cal.firstDayOfWeek = Calendar.MONDAY
  val parsed = parseDate(anchor)
  if (parsed != null) cal.time = parsed
  return if (period == "week") {
    cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    val start = fmtDate(cal.time)
    cal.add(Calendar.DAY_OF_YEAR, 6)
    Pair(start, fmtDate(cal.time))
  } else {
    cal.set(Calendar.DAY_OF_MONTH, 1)
    val start = fmtDate(cal.time)
    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
    Pair(start, fmtDate(cal.time))
  }
}

fun shiftPeriod(period: String, anchor: String, dir: Int): String {
  val cal = Calendar.getInstance()
  val parsed = parseDate(anchor)
  if (parsed != null) cal.time = parsed
  if (period == "week") cal.add(Calendar.DAY_OF_YEAR, 7 * dir) else cal.add(Calendar.MONTH, dir)
  return fmtDate(cal.time)
}

fun monthKey(): String {
  val f = SimpleDateFormat("yyyy-MM", Locale.US)
  f.timeZone = TimeZone.getTimeZone("UTC")
  return f.format(Date())
}

fun money(v: Double): String {
  val s = if (v == Math.floor(v)) {
    String.format(Locale.US, "%,.0f", v)
  } else {
    String.format(Locale.US, "%,.2f", v)
  }
  return "\u20A6" + s
}

fun trimNum(v: Double): String =
  if (v == Math.floor(v)) v.toLong().toString() else v.toString()

fun generateCode(): String {
  val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
  val rnd = SecureRandom()
  val sb = StringBuilder()
  repeat(8) { sb.append(chars[rnd.nextInt(chars.length)]) }
  return sb.toString()
}

// ---------------------------------------------------------------- models

data class Item(
  val id: String,
  val name: String,
  val price: Double,
  val stock: Long,
  val vault: Long = 0L,
)

data class Line(val itemId: String, val name: String, val price: Double, val qty: Long)

data class Expense(val desc: String, val amount: Double)

data class DayRecord(
  val date: String,
  val lines: List<Line>,
  val expenses: List<Expense>,
  val submittedBy: String,
  val cash: Double = 0.0,
  val transfer: Double = 0.0,
  val status: String = "submitted",
) {
  val sales: Double get() = lines.sumOf { it.price * it.qty }
  val spent: Double get() = expenses.sumOf { it.amount }
  val remitted: Double get() = cash + transfer
}

private fun DocumentSnapshot.toItem(): Item =
  Item(
    id,
    getString("name").orEmpty(),
    getDouble("price") ?: 0.0,
    getLong("stock") ?: 0L,
    getLong("vault") ?: 0L,
  )

private fun DocumentSnapshot.toDay(): DayRecord {
  val lines = (get("lines") as? List<*>)?.mapNotNull { raw ->
    val m = raw as? Map<*, *> ?: return@mapNotNull null
    Line(
      itemId = m["itemId"] as? String ?: "",
      name = m["name"] as? String ?: "",
      price = (m["price"] as? Number)?.toDouble() ?: 0.0,
      qty = (m["qty"] as? Number)?.toLong() ?: 0L,
    )
  } ?: emptyList()
  val expenses = (get("expenses") as? List<*>)?.mapNotNull { raw ->
    val m = raw as? Map<*, *> ?: return@mapNotNull null
    Expense(
      desc = m["desc"] as? String ?: "",
      amount = (m["amount"] as? Number)?.toDouble() ?: 0.0,
    )
  } ?: emptyList()
  return DayRecord(
    getString("date") ?: id,
    lines,
    expenses,
    getString("submittedBy").orEmpty(),
    getDouble("cash") ?: 0.0,
    getDouble("transfer") ?: 0.0,
    getString("status") ?: "submitted",
  )
}

class RowState(
  val itemId: String,
  val name: String,
  val price: Double,
  val stock: Long?,
  initialQty: String,
) {
  var qty by mutableStateOf(initialQty)
}

class ExpenseState(initialDesc: String, initialAmount: String) {
  var desc by mutableStateOf(initialDesc)
  var amount by mutableStateOf(initialAmount)
}

private fun buildRows(catalog: List<Item>, existing: DayRecord?): SnapshotStateList<RowState> {
  val list = mutableStateListOf<RowState>()
  catalog.forEach { item ->
    val oldLine = existing?.lines?.firstOrNull { it.itemId == item.id }
    val oldQty = oldLine?.qty ?: 0L
    list.add(
      RowState(
        item.id,
        item.name,
        oldLine?.price ?: item.price,
        item.stock,
        if (oldQty > 0L) oldQty.toString() else "",
      ),
    )
  }
  existing?.lines
    ?.filter { l -> catalog.none { it.id == l.itemId } && l.qty > 0L }
    ?.forEach { l -> list.add(RowState(l.itemId, l.name, l.price, null, l.qty.toString())) }
  return list
}

// ---------------------------------------------------------------- activity

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val prefs = getSharedPreferences("buzz_biz_prefs", MODE_PRIVATE)
    setContent {
      var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
      MaterialTheme(colorScheme = if (dark) BuzzDarkScheme else BuzzLightScheme) {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background,
        ) {
          RootApp(
            dark = dark,
            onDarkChange = { value ->
              dark = value
              prefs.edit().putBoolean("dark", value).apply()
            },
          )
        }
      }
    }
  }
}

@Composable
fun RootApp(dark: Boolean, onDarkChange: (Boolean) -> Unit) {
  val auth = remember { FirebaseAuth.getInstance() }
  var uid by remember { mutableStateOf(auth.currentUser?.uid) }

  DisposableEffect(auth) {
    val listener = FirebaseAuth.AuthStateListener { fb -> uid = fb.currentUser?.uid }
    auth.addAuthStateListener(listener)
    onDispose { auth.removeAuthStateListener(listener) }
  }

  val currentUid = uid
  if (currentUid == null) {
    AuthScreen(auth)
  } else {
    Gate(currentUid, auth, dark, onDarkChange)
  }
}

// ---------------------------------------------------------------- sign in

@Composable
fun AuthScreen(auth: FirebaseAuth) {
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var confirm by remember { mutableStateOf("") }
  var creating by remember { mutableStateOf(false) }
  var showPassword by remember { mutableStateOf(false) }
  var busy by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }
  var info by remember { mutableStateOf<String?>(null) }
  val fieldShape = RoundedCornerShape(16.dp)
  val mismatch = creating && confirm.isNotEmpty() && confirm != password

  Column(
    modifier = Modifier
      .fillMaxSize()
      .systemBarsPadding()
      .imePadding()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 24.dp, vertical = 12.dp),
  ) {
    if (creating) {
      IconButton(onClick = { creating = false; error = null; info = null }) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to sign in")
      }
    } else {
      Spacer(modifier = Modifier.height(48.dp))
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top,
    ) {
      Column(modifier = Modifier
        .weight(1f)
        .padding(top = 28.dp)) {
        Text(
          if (creating) "Create\nAccount" else "Welcome\nBack!",
          fontSize = 34.sp,
          lineHeight = 40.sp,
          fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          if (creating) "Sign up to get started" else "Sign in to your account",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      Image(
        painter = painterResource(R.drawable.buzz_logo),
        contentDescription = "Buzz Biz logo",
        modifier = Modifier.size(116.dp),
      )
    }

    Spacer(modifier = Modifier.height(28.dp))

    OutlinedTextField(
      value = email,
      onValueChange = { email = it },
      placeholder = { Text("Email") },
      leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = BuzzGold) },
      singleLine = true,
      shape = fieldShape,
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
      modifier = Modifier.fillMaxWidth(),
    )
    Spacer(modifier = Modifier.height(12.dp))
    OutlinedTextField(
      value = password,
      onValueChange = { password = it },
      placeholder = { Text("Password (6+ characters)") },
      leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = BuzzGold) },
      trailingIcon = {
        TextButton(onClick = { showPassword = !showPassword }) {
          Text(if (showPassword) "Hide" else "Show", color = BuzzGold)
        }
      },
      singleLine = true,
      shape = fieldShape,
      visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
      modifier = Modifier.fillMaxWidth(),
    )
    if (creating) {
      Spacer(modifier = Modifier.height(12.dp))
      OutlinedTextField(
        value = confirm,
        onValueChange = { confirm = it },
        placeholder = { Text("Confirm password") },
        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = BuzzGold) },
        singleLine = true,
        shape = fieldShape,
        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth(),
      )
    } else {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(
          onClick = {
            if (email.isBlank()) {
              error = "Enter your email above first."
              info = null
            } else {
              auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { r ->
                if (r.isSuccessful) {
                  info = "Reset link sent. Check your email."
                  error = null
                } else {
                  error = r.exception?.localizedMessage ?: "Couldn't send the reset email."
                  info = null
                }
              }
            }
          },
        ) { Text("Forgot Password?", color = BuzzGold) }
      }
    }

    if (mismatch) {
      Text("Passwords don't match.", color = MaterialTheme.colorScheme.error)
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    info?.let { Text(it, color = BuzzGreen) }

    Spacer(modifier = Modifier.height(16.dp))
    GoldButton(
      text = if (creating) "Create Account" else "Login",
      enabled = !busy && email.isNotBlank() && password.length >= 6 && (!creating || confirm == password),
      onClick = {
        busy = true
        error = null
        info = null
        val task = if (creating) {
          auth.createUserWithEmailAndPassword(email.trim(), password)
        } else {
          auth.signInWithEmailAndPassword(email.trim(), password)
        }
        task.addOnCompleteListener { result ->
          busy = false
          if (!result.isSuccessful) {
            error = result.exception?.localizedMessage ?: "Something went wrong. Try again."
          }
        }
      },
    )

    Spacer(modifier = Modifier.height(22.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        if (creating) "Already have an account? " else "Don't have an account? ",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        if (creating) "Log in" else "Sign up",
        color = BuzzGold,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clickable {
          creating = !creating
          error = null
          info = null
        },
      )
    }
  }
}

// ---------------------------------------------------------------- gate + onboarding

@Composable
fun Gate(uid: String, auth: FirebaseAuth, dark: Boolean, onDarkChange: (Boolean) -> Unit) {
  val db = remember { FirebaseFirestore.getInstance() }
  val profileRef = remember(uid) { db.collection("users").document(uid) }
  var loaded by remember(uid) { mutableStateOf(false) }
  var businessId by remember(uid) { mutableStateOf<String?>(null) }

  DisposableEffect(uid) {
    val registration = profileRef.addSnapshotListener { snap, _ ->
      if (snap != null) {
        if (snap.exists() || !snap.metadata.isFromCache) {
          businessId = snap.getString("businessId")
          loaded = true
        }
      }
    }
    onDispose { registration.remove() }
  }

  val bid = businessId
  if (!loaded) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .systemBarsPadding()
        .padding(24.dp),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text("Loading...")
    }
  } else if (bid.isNullOrBlank()) {
    Onboarding(uid, auth, dark)
  } else {
    BusinessHome(
      uid = uid,
      bid = bid,
      auth = auth,
      dark = dark,
      onDarkChange = onDarkChange,
      onLeave = { profileRef.delete() },
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Onboarding(uid: String, auth: FirebaseAuth, dark: Boolean) {
  val db = remember { FirebaseFirestore.getInstance() }
  var mode by remember { mutableStateOf("choose") }
  var name by remember { mutableStateOf("") }
  var code by remember { mutableStateOf("") }
  var busy by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }

  Scaffold(
    topBar = { TopAppBar(title = { Text("Set up your business") }) },
  ) { padding ->
    Column(
      modifier = Modifier
        .padding(padding)
        .padding(20.dp)
        .fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      if (mode == "choose") {
        Text(
          "Are you the manager creating a new business, or staff joining one?",
          style = MaterialTheme.typography.titleMedium,
        )
        Button(onClick = { mode = "create" }, modifier = Modifier.fillMaxWidth()) {
          Text("I'm the manager: create a business")
        }
        OutlinedButton(onClick = { mode = "join" }, modifier = Modifier.fillMaxWidth()) {
          Text("I'm staff: join with a code")
        }
      }

      if (mode == "create") {
        Text("Business name", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("e.g. My Shop") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
          enabled = !busy && name.isNotBlank(),
          modifier = Modifier.fillMaxWidth(),
          onClick = {
            busy = true
            error = null
            val newCode = generateCode()
            val batch = db.batch()
            batch.set(
              db.collection("businesses").document(newCode),
              hashMapOf<String, Any>(
                "managerUid" to uid,
                "staffUid" to "",
                "name" to name.trim(),
                "createdAt" to FieldValue.serverTimestamp(),
              ),
            )
            batch.set(
              db.collection("users").document(uid),
              hashMapOf<String, Any>("businessId" to newCode, "role" to "manager"),
            )
            batch.commit().addOnCompleteListener { result ->
              busy = false
              if (!result.isSuccessful) {
                error = "Couldn't create the business. Check your internet and try again."
              }
            }
          },
        ) { Text("Create business") }
      }

      if (mode == "join") {
        Text("Enter the join code from your manager", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
          value = code,
          onValueChange = { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(8) },
          label = { Text("Join code") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
          enabled = !busy && code.length == 8,
          modifier = Modifier.fillMaxWidth(),
          onClick = {
            busy = true
            error = null
            val joinCode = code
            db.collection("businesses").document(joinCode)
              .update("staffUid", uid)
              .addOnCompleteListener { result ->
                if (result.isSuccessful) {
                  db.collection("users").document(uid)
                    .set(hashMapOf<String, Any>("businessId" to joinCode, "role" to "staff"))
                    .addOnCompleteListener { busy = false }
                } else {
                  busy = false
                  error = "Couldn't join. Check the code, or the staff spot may already be taken."
                }
              }
          },
        ) { Text("Join business") }
      }

      if (mode != "choose") {
        TextButton(onClick = { mode = "choose"; error = null }) { Text("Back") }
      }
      TextButton(onClick = { auth.signOut() }) { Text("Sign out") }
    }
  }
}

// ---------------------------------------------------------------- business home

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessHome(
  uid: String,
  bid: String,
  auth: FirebaseAuth,
  dark: Boolean,
  onDarkChange: (Boolean) -> Unit,
  onLeave: () -> Unit,
) {
  val db = remember { FirebaseFirestore.getInstance() }
  val context = LocalContext.current
  val bizRef = remember(bid) { db.collection("businesses").document(bid) }

  var bizName by remember { mutableStateOf("") }
  var managerUid by remember { mutableStateOf<String?>(null) }
  var staffUid by remember { mutableStateOf<String?>(null) }
  var bizLoaded by remember { mutableStateOf(false) }
  var bizGone by remember { mutableStateOf(false) }
  var deletingBiz by remember { mutableStateOf(false) }
  val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
  var bizConfirmed by remember { mutableStateOf(false) }
  var errorCount by remember { mutableStateOf(0) }
  var retryKey by remember { mutableStateOf(0) }
  val mainHandler = remember { Handler(Looper.getMainLooper()) }
  var catalog by remember { mutableStateOf<List<Item>>(emptyList()) }
  var days by remember { mutableStateOf<List<DayRecord>>(emptyList()) }
  var logs by remember { mutableStateOf<List<LogEntry>>(emptyList()) }
  var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
  var masterDocs by remember { mutableStateOf<List<MasterDoc>>(emptyList()) }
  var logClearedMonth by remember { mutableStateOf("") }
  var staffTab by remember { mutableStateOf(0) }

  var screen by remember { mutableStateOf("main") }
  var tab by remember { mutableStateOf(0) }
  var editorDate by remember { mutableStateOf(todayString()) }
  var itemDialog by remember { mutableStateOf<Item?>(null) }
  var dashDate by remember { mutableStateOf(todayString()) }

  DisposableEffect(bid, retryKey) {
    val registration = bizRef.addSnapshotListener { snap, e ->
      if (e != null) {
        errorCount += 1
        mainHandler.postDelayed({ retryKey += 1 }, 3000)
      } else if (snap != null && snap.exists()) {
        bizName = snap.getString("name").orEmpty()
        managerUid = snap.getString("managerUid")
        staffUid = snap.getString("staffUid")
        logClearedMonth = snap.getString("logClearedMonth").orEmpty()
        bizConfirmed = !snap.metadata.hasPendingWrites()
        bizLoaded = true
        bizGone = false
        errorCount = 0
      } else if (snap != null && !snap.exists() && !snap.metadata.isFromCache) {
        bizGone = true
      }
    }
    onDispose { registration.remove() }
  }

  val role = when (uid) {
    managerUid -> "manager"
    staffUid -> "staff"
    else -> "none"
  }
  val isManager = role == "manager"

  DisposableEffect(bid, role, bizConfirmed, retryKey, bizGone) {
    val regs = mutableListOf<com.google.firebase.firestore.ListenerRegistration>()
    if (role == "manager" && bizConfirmed && !bizGone) {
      regs.add(
        bizRef.collection("logs")
          .orderBy("at", Query.Direction.DESCENDING)
          .limit(200)
          .addSnapshotListener { s, e ->
            if (e != null) {
              mainHandler.postDelayed({ retryKey += 1 }, 3000)
            } else if (s != null) {
              logs = s.documents.map { it.toLogEntry() }
            }
          },
      )
      regs.add(
        bizRef.collection("master").addSnapshotListener { s, e ->
          if (e != null) {
            mainHandler.postDelayed({ retryKey += 1 }, 3000)
          } else if (s != null) {
            masterDocs = s.documents.map { it.toMasterDoc() }
          }
        },
      )
    }
    if (role != "none" && bizConfirmed && !bizGone) {
      regs.add(
        bizRef.collection("items").orderBy("name").addSnapshotListener { s, e ->
          if (e != null) {
            mainHandler.postDelayed({ retryKey += 1 }, 3000)
          } else if (s != null) {
            catalog = s.documents.map { it.toItem() }
          }
        },
      )
      regs.add(
        bizRef.collection("days")
          .orderBy("date", Query.Direction.DESCENDING)
          .limit(400)
          .addSnapshotListener { s, e ->
            if (e != null) {
              mainHandler.postDelayed({ retryKey += 1 }, 3000)
            } else if (s != null) {
              days = s.documents.map { it.toDay() }
            }
          },
      )
      regs.add(
        bizRef.collection("requests")
          .orderBy("createdAt", Query.Direction.DESCENDING)
          .limit(50)
          .addSnapshotListener { s, e ->
            if (e != null) {
              mainHandler.postDelayed({ retryKey += 1 }, 3000)
            } else if (s != null) {
              requests = s.documents.map { it.toRequest() }
            }
          },
      )
    }
    onDispose {
      regs.forEach { it.remove() }
    }
  }

  fun toast(msg: String) {
    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
  }

  fun logEntry(batch: WriteBatch, action: String, date: String, summary: String, detail: String) {
    batch.set(
      bizRef.collection("logs").document(),
      hashMapOf<String, Any>(
        "at" to FieldValue.serverTimestamp(),
        "action" to action,
        "date" to date,
        "byUid" to uid,
        "byRole" to role,
        "byEmail" to (auth.currentUser?.email ?: ""),
        "summary" to summary,
        "detail" to detail,
      ),
    )
  }

  fun deleteDay(date: String, existing: DayRecord) {
    val batch = db.batch()
    batch.delete(bizRef.collection("days").document(date))
    existing.lines.forEach { l ->
      if (existing.status == "submitted" && l.qty > 0L && catalog.any { it.id == l.itemId }) {
        batch.update(
          bizRef.collection("items").document(l.itemId),
          "stock",
          FieldValue.increment(l.qty),
        )
      }
    }
    logEntry(
      batch,
      "deleted",
      date,
      "Manager deleted the record for $date",
      describeRecord(existing.lines, existing.expenses, existing.cash, existing.transfer),
    )
    batch.commit().addOnFailureListener {
      toast("The record for $date could not be deleted.")
    }
  }

  fun submitDay(
    date: String,
    existing: DayRecord?,
    lines: List<Line>,
    exps: List<Expense>,
    cash: Double,
    transfer: Double,
    submit: Boolean,
  ) {
    val dayRef = bizRef.collection("days").document(date)
    val data = hashMapOf<String, Any>(
      "date" to date,
      "status" to (if (submit) "submitted" else "draft"),
      "submittedBy" to (existing?.submittedBy?.ifBlank { uid } ?: uid),
      "lines" to lines.map {
        hashMapOf<String, Any>(
          "itemId" to it.itemId,
          "name" to it.name,
          "price" to it.price,
          "qty" to it.qty,
        )
      },
      "expenses" to exps.map {
        hashMapOf<String, Any>("desc" to it.desc, "amount" to it.amount)
      },
      "cash" to cash,
      "transfer" to transfer,
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    val batch = db.batch()
    batch.set(dayRef, data)
    val wasSubmitted = existing?.status == "submitted"
    val oldQty: Map<String, Long> = if (wasSubmitted) {
      existing?.lines?.associate { it.itemId to it.qty } ?: emptyMap()
    } else {
      emptyMap()
    }
    val newQty: Map<String, Long> = if (submit) {
      lines.associate { it.itemId to it.qty }
    } else {
      emptyMap()
    }
    (oldQty.keys + newQty.keys).forEach { id ->
      val delta = (oldQty[id] ?: 0L) - (newQty[id] ?: 0L)
      if (delta != 0L && catalog.any { it.id == id }) {
        batch.update(
          bizRef.collection("items").document(id),
          "stock",
          FieldValue.increment(delta),
        )
      }
    }
    if (submit) {
      if (!wasSubmitted || existing == null) {
        logEntry(
          batch,
          "submitted",
          date,
          (if (isManager) "Manager added the record for " else "Staff submitted the record for ") + date,
          describeRecord(lines, exps, cash, transfer),
        )
      } else {
        logEntry(
          batch,
          "edited",
          date,
          "Manager edited the record for $date",
          "Before: " + describeRecord(existing.lines, existing.expenses, existing.cash, existing.transfer) +
            "\nAfter: " + describeRecord(lines, exps, cash, transfer),
        )
      }
    }
    batch.commit().addOnFailureListener {
      toast("The record for $date could not be saved. It may already be submitted.")
    }
  }

  fun saveItem(item: Item, name: String, price: Double, stock: Long, vault: Long) {
    val data = hashMapOf<String, Any>(
      "name" to name,
      "price" to price,
      "stock" to stock,
      "vault" to vault,
    )
    val col = bizRef.collection("items")
    if (item.id.isEmpty()) {
      col.add(data)
    } else {
      col.document(item.id).set(data, SetOptions.merge())
    }
  }

  fun addMasterItems(names: List<String>, defaults: Map<String, Pair<Double, Long>>) {
    val col = bizRef.collection("items")
    names.chunked(400).forEach { chunk ->
      val batch = db.batch()
      chunk.forEach { n ->
        val d = defaults[n.trim().lowercase()]
        batch.set(
          col.document(),
          hashMapOf<String, Any>(
            "name" to n,
            "price" to (d?.first ?: 0.0),
            "stock" to (d?.second ?: 0L),
            "vault" to 0L,
          ),
        )
      }
      batch.commit()
    }
  }

  fun importMasterRows(rows: List<CsvRow>) {
    val col = bizRef.collection("master")
    rows.chunked(400).forEach { chunk ->
      val batch = db.batch()
      chunk.forEach { r ->
        val data = hashMapOf<String, Any>(
          "kind" to "add",
          "name" to r.name.trim(),
          "category" to r.category.trim(),
        )
        val pr = r.price
        val st = r.stock
        if (pr != null) data["price"] = pr
        if (st != null) data["stock"] = st
        batch.set(col.document(), data)
      }
      batch.commit().addOnFailureListener { toast("Couldn't import some of the items.") }
    }
    toast("Importing " + rows.size + " items...")
  }

  fun linesText(lines: List<Line>): String =
    lines.joinToString(", ") { it.name + " \u00D7 " + it.qty }

  fun submitReceived(lines: List<Line>) {
    val batch = db.batch()
    val reqRef = bizRef.collection("requests").document()
    batch.set(
      reqRef,
      hashMapOf<String, Any>(
        "status" to "pending",
        "byUid" to uid,
        "byEmail" to (auth.currentUser?.email ?: ""),
        "createdAt" to FieldValue.serverTimestamp(),
        "lines" to lines.map {
          hashMapOf<String, Any>("itemId" to it.itemId, "name" to it.name, "qty" to it.qty)
        },
      ),
    )
    lines.forEach { l ->
      batch.update(bizRef.collection("items").document(l.itemId), "stock", FieldValue.increment(l.qty))
    }
    logEntry(
      batch,
      "received",
      todayString(),
      "Staff added received items (waiting for approval)",
      linesText(lines),
    )
    batch.commit().addOnFailureListener {
      toast("The received items could not be saved. Check your internet and try again.")
    }
  }

  fun approveRequest(req: StockRequest) {
    if (req.status != "pending") return
    for (l in req.lines) {
      val item = catalog.firstOrNull { it.id == l.itemId }
      if (item == null) {
        toast(l.name + " is no longer on your item list.")
        return
      }
      if (item.vault < l.qty) {
        toast("Not enough stock inventory for " + l.name + " (" + item.vault + " left).")
        return
      }
    }
    val batch = db.batch()
    batch.update(
      bizRef.collection("requests").document(req.id),
      mapOf<String, Any>("status" to "approved", "decidedAt" to FieldValue.serverTimestamp()),
    )
    req.lines.forEach { l ->
      batch.update(bizRef.collection("items").document(l.itemId), "vault", FieldValue.increment(-l.qty))
    }
    logEntry(batch, "approved", todayString(), "Manager approved received items", linesText(req.lines))
    batch.commit().addOnFailureListener { toast("Couldn't approve the request.") }
  }

  fun rejectRequest(req: StockRequest) {
    if (req.status != "pending") return
    val batch = db.batch()
    batch.update(
      bizRef.collection("requests").document(req.id),
      mapOf<String, Any>("status" to "rejected", "decidedAt" to FieldValue.serverTimestamp()),
    )
    req.lines.forEach { l ->
      val item = catalog.firstOrNull { it.id == l.itemId }
      if (item != null) {
        batch.update(
          bizRef.collection("items").document(l.itemId),
          "stock",
          maxOf(0L, item.stock - l.qty),
        )
      }
    }
    logEntry(
      batch,
      "rejected",
      todayString(),
      "Manager rejected received items (taken out of the store)",
      linesText(req.lines),
    )
    batch.commit().addOnFailureListener { toast("Couldn't reject the request.") }
  }

  fun moveToStore(item: Item, qty: Long) {
    if (qty <= 0L || qty > item.vault) {
      toast("Not enough stock inventory.")
      return
    }
    val batch = db.batch()
    val ref = bizRef.collection("items").document(item.id)
    batch.update(ref, "vault", FieldValue.increment(-qty))
    batch.update(ref, "stock", FieldValue.increment(qty))
    logEntry(
      batch,
      "moved",
      todayString(),
      "Manager moved items from stock to store",
      item.name + " \u00D7 " + qty,
    )
    batch.commit().addOnFailureListener { toast("Couldn't move the items.") }
  }

  fun addMasterEntry(name: String, category: String) {
    if (name.isBlank()) return
    bizRef.collection("master").add(
      hashMapOf<String, Any>(
        "kind" to "add",
        "name" to name.trim(),
        "category" to category.trim(),
      ),
    )
  }

  fun removeMasterEntry(name: String, customId: String?) {
    val col = bizRef.collection("master")
    if (customId != null) {
      col.document(customId).delete()
    } else {
      col.add(hashMapOf<String, Any>("kind" to "hide", "name" to name.trim()))
    }
  }

  fun restoreMasterEntries(ids: List<String>) {
    if (ids.isEmpty()) return
    val batch = db.batch()
    ids.forEach { batch.delete(bizRef.collection("master").document(it)) }
    batch.commit()
  }

  fun purgeDecidedRequests() {
    bizRef.collection("requests").limit(450).get().addOnSuccessListener { rs ->
      val decided = rs.documents.filter { it.getString("status") != "pending" }
      if (decided.isNotEmpty()) {
        val b = db.batch()
        decided.forEach { b.delete(it.reference) }
        b.commit().addOnFailureListener {
          toast("Couldn't remove the old inventory receipts.")
        }
      }
    }
  }

  fun clearLog() {
    bizRef.collection("logs").limit(450).get().addOnSuccessListener { snap ->
      val batch = db.batch()
      snap.documents.forEach { batch.delete(it.reference) }
      batch.update(bizRef, "logClearedMonth", monthKey())
      logEntry(
        batch,
        "cleared",
        todayString(),
        "Manager cleared the activity log",
        "Removed " + snap.size() + " entries and old inventory receipts.",
      )
      batch.commit().addOnSuccessListener {
        purgeDecidedRequests()
      }.addOnFailureListener {
        toast("Couldn't clear the log. It can only be cleared once a month.")
      }
    }.addOnFailureListener {
      toast("Couldn't load the log to clear it.")
    }
  }

  fun purgeCollection(name: String, next: () -> Unit) {
    bizRef.collection(name).limit(400).get().addOnSuccessListener { snap ->
      if (snap.isEmpty) {
        next()
      } else {
        val batch = db.batch()
        snap.documents.forEach { batch.delete(it.reference) }
        batch.commit().addOnSuccessListener {
          purgeCollection(name, next)
        }.addOnFailureListener {
          deletingBiz = false
          toast("Couldn't finish deleting. Check your internet and try again.")
        }
      }
    }.addOnFailureListener {
      deletingBiz = false
      toast("Couldn't finish deleting. Check your internet and try again.")
    }
  }

  fun deleteBusiness() {
    deletingBiz = true
    bizRef.update("deleting", true).addOnSuccessListener {
      purgeCollection("items") {
        purgeCollection("days") {
          purgeCollection("requests") {
            purgeCollection("logs") {
              purgeCollection("master") {
                bizRef.delete().addOnSuccessListener {
                  db.collection("users").document(uid).delete()
                }.addOnFailureListener {
                  deletingBiz = false
                  toast("Couldn't delete the business.")
                }
              }
            }
          }
        }
      }
    }.addOnFailureListener {
      deletingBiz = false
      toast("Couldn't start deleting the business.")
    }
  }

  fun shareLog() {
    val f = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.US)
    val text = logs.joinToString("\n\n") { e ->
      val whenText = if (e.atMillis > 0L) f.format(Date(e.atMillis)) else "just now"
      val who = if (e.role == "manager") "Manager" else "Staff"
      whenText + " - " + who + ": " + e.summary + (if (e.detail.isNotBlank()) "\n" + e.detail else "")
    }
    val intent = Intent(Intent.ACTION_SEND)
    intent.type = "text/plain"
    intent.putExtra(Intent.EXTRA_TEXT, text)
    context.startActivity(Intent.createChooser(intent, "Share activity log"))
  }

  fun deleteItem(item: Item) {
    if (item.id.isNotEmpty()) bizRef.collection("items").document(item.id).delete()
  }

  // ---- screens
  if (deletingBiz) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .systemBarsPadding()
        .padding(24.dp),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text("Deleting business...")
    }
    return
  }

  if (bizGone || !bizLoaded || role == "none") {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .systemBarsPadding()
        .padding(24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      if (!bizGone && !bizLoaded && errorCount < 3) {
        Text("Loading...")
      } else {
        Text(if (bizGone) "This business was deleted." else "You no longer have access to this business.")
        Button(onClick = onLeave) { Text("Start over") }
        TextButton(onClick = { auth.signOut() }) { Text("Sign out") }
      }
    }
    return
  }

  if (screen == "settings") {
    SettingsScreen(
      email = auth.currentUser?.email.orEmpty(),
      role = role,
      bizName = bizName,
      code = bid,
      staffJoined = !staffUid.isNullOrBlank(),
      dark = dark,
      onDarkChange = onDarkChange,
      onRemoveStaff = { bizRef.update("staffUid", "") },
      onOpenLog = { screen = "log" },
      onDeleteBusiness = { deleteBusiness() },
      onSignOut = {
        screen = "main"
        auth.signOut()
      },
      onBack = { screen = "main" },
    )
    return
  }

  if (screen == "log") {
    val canClear = logClearedMonth != monthKey()
    ActivityLogScreen(
      logs = logs,
      canClear = canClear,
      clearNote = if (canClear) "" else "The log was already cleared this month. You can clear it again next month.",
      onClear = { clearLog() },
      onShare = { shareLog() },
      onBack = { screen = "settings" },
    )
    return
  }

  val masterView = buildMasterView(masterDocs)

  if (screen == "master") {
    MasterPickerScreen(
      catalog = catalog,
      categories = masterView.categories,
      hiddenCount = masterView.hiddenIds.size,
      onAdd = { names ->
        addMasterItems(names, masterView.defaults)
        tab = 1
        screen = "main"
      },
      onAddMaster = { name, category -> addMasterEntry(name, category) },
      onImportRows = { rows -> importMasterRows(rows) },
      onRemoveMaster = { name -> removeMasterEntry(name, masterView.customIds[name.trim().lowercase()]) },
      onRestore = { restoreMasterEntries(masterView.hiddenIds) },
      onBack = { screen = "main" },
    )
    return
  }

  if (screen == "editor") {
    DayEditorScreen(
      initialDate = editorDate,
      isManager = isManager,
      catalog = catalog,
      days = days,
      onSubmit = { date, existing, lines, exps, cash, transfer ->
        val submitNow = if (existing != null) existing.status == "submitted" else date < todayString()
        submitDay(date, existing, lines, exps, cash, transfer, submitNow)
      },
      onDelete = { date, record -> deleteDay(date, record) },
      onBack = { screen = "main" },
    )
    return
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(bizName.ifBlank { "Business" }) },
        actions = {
          IconButton(onClick = { screen = "settings" }) {
            Icon(Icons.Default.Settings, contentDescription = "Settings")
          }
        },
      )
    },
    bottomBar = {
      if (imeOpen) {
        // keep the screen clear while typing
      } else if (isManager) {
        NavigationBar {
          NavigationBarItem(
            selected = tab == 0,
            onClick = { tab = 0 },
            icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
            label = { Text("Days") },
          )
          NavigationBarItem(
            selected = tab == 1,
            onClick = { tab = 1 },
            icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
            label = { Text("Items") },
          )
          NavigationBarItem(
            selected = tab == 2,
            onClick = { tab = 2 },
            icon = { Icon(Icons.Default.Home, contentDescription = null) },
            label = {
              val pendingCount = requests.count { it.status == "pending" }
              Text(if (pendingCount > 0) "Inventory ($pendingCount)" else "Inventory")
            },
          )
          NavigationBarItem(
            selected = tab == 3,
            onClick = { tab = 3 },
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            label = { Text("Reports") },
          )
        }
      } else {
        NavigationBar {
          NavigationBarItem(
            selected = staffTab == 0,
            onClick = { staffTab = 0 },
            icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
            label = { Text("Record") },
          )
          NavigationBarItem(
            selected = staffTab == 1,
            onClick = { staffTab = 1 },
            icon = { Icon(Icons.Default.Home, contentDescription = null) },
            label = { Text("Inventory") },
          )
        }
      }
    },
    floatingActionButton = {
      if (isManager && tab == 1) {
        FloatingActionButton(
          onClick = {
            if (tab == 0) {
              editorDate = dashDate
              screen = "editor"
            } else {
              itemDialog = Item("", "", 0.0, 0L)
            }
          },
        ) {
          Icon(Icons.Default.Add, contentDescription = "Add")
        }
      }
    },
  ) { padding ->
    Column(
      modifier = Modifier
        .padding(padding)
        .padding(horizontal = 16.dp)
        .fillMaxSize(),
    ) {
      if (!isManager) {
        if (staffTab == 0) {
          StaffRecordScreen(
            catalog = catalog,
            days = days,
            onSave = { date, existing, lines, exps, cash, transfer, submit ->
              submitDay(date, existing, lines, exps, cash, transfer, submit)
            },
          )
        } else {
          StaffInventoryScreen(
            catalog = catalog,
            requests = requests,
            onSubmit = { lines -> submitReceived(lines) },
          )
        }
      } else if (tab == 0) {
        DaysTab(
          days = days,
          selectedDate = dashDate,
          onSelect = { dashDate = it },
          onOpen = { date ->
            editorDate = date
            screen = "editor"
          },
        )
      } else if (tab == 1) {
        ItemsTab(
          catalog = catalog,
          onEdit = { itemDialog = it },
          onMaster = { screen = "master" },
        )
      } else if (tab == 2) {
        ManagerInventoryTab(
          catalog = catalog,
          requests = requests,
          onApprove = { approveRequest(it) },
          onReject = { rejectRequest(it) },
          onMove = { item, qty -> moveToStore(item, qty) },
        )
      } else {
        ReportsTab(days = days.filter { it.status != "draft" })
      }
    }
  }

  val dialogItem = itemDialog
  if (dialogItem != null) {
    ItemDialog(
      item = dialogItem,
      catalog = catalog,
      masterNames = masterView.names,
      onSave = { name, price, stock, vault ->
        saveItem(dialogItem, name, price, stock, vault)
        itemDialog = null
      },
      onDelete = {
        deleteItem(dialogItem)
        itemDialog = null
      },
      onDismiss = { itemDialog = null },
    )
  }
}

@Composable
fun StaffHome(days: List<DayRecord>, onRecord: () -> Unit) {
  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Text(
      "Enter each day's items sold and expenses, then submit. Once submitted, only the manager can change a record.",
      style = MaterialTheme.typography.bodyMedium,
    )
    Button(onClick = onRecord, modifier = Modifier.fillMaxWidth()) {
      Text("Record a day")
    }
    Text("Submitted days", style = MaterialTheme.typography.titleMedium)
    if (days.isEmpty()) Text("Nothing submitted yet.")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      items(days) { d ->
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(d.date, style = MaterialTheme.typography.titleMedium)
            Text("Submitted")
          }
        }
      }
    }
  }
}

@Composable
fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
  }
}

@Composable
fun DaysTab(
  days: List<DayRecord>,
  selectedDate: String,
  onSelect: (String) -> Unit,
  onOpen: (String) -> Unit,
) {
  val today = todayString()
  val record = days.firstOrNull { it.date == selectedDate }
  val listDays = days.filter { it.status != "draft" }
  var drag by remember { mutableStateOf(0f) }
  val label = when (selectedDate) {
    today -> "Today"
    shiftDate(today, -1) -> "Yesterday"
    else -> selectedDate
  }
  val sales = record?.sales ?: 0.0
  val spent = record?.spent ?: 0.0
  val remitted = record?.remitted ?: 0.0

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("Dashboard", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
          Text(
            "Business Performance Overview",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp)),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = { onSelect(shiftDate(selectedDate, -1)) }) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous day")
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontWeight = FontWeight.SemiBold)
            if (label != selectedDate) {
              Text(selectedDate, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          IconButton(
            enabled = selectedDate < today,
            onClick = { onSelect(shiftDate(selectedDate, 1)) },
          ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next day")
          }
        }
      }
    }

    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpen(selectedDate) }
          .pointerInput(selectedDate) {
            detectHorizontalDragGestures(
              onDragStart = { drag = 0f },
              onDragEnd = {
                if (drag > 100f) {
                  onSelect(shiftDate(selectedDate, -1))
                } else if (drag < -100f && selectedDate < today) {
                  onSelect(shiftDate(selectedDate, 1))
                }
                drag = 0f
              },
              onDragCancel = { drag = 0f },
              onHorizontalDrag = { _, amount -> drag += amount },
            )
          },
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (selectedDate != today) {
          TextButton(onClick = { onSelect(today) }) { Text("Back to today") }
        }
        if (record != null && record.status == "draft") {
          StatusBadge("In progress, updating from staff", BuzzGold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          StatTile("Total Sales", money(sales), "\u20A6", BuzzBlue, Modifier.weight(1f))
          StatTile("Expenses", money(spent), "\u2212", BuzzGold, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          StatTile("Net Sales", money(sales - spent), "=", BuzzGreen, Modifier.weight(1f))
          StatTile("Total Remitted", money(remitted), "\u2192", BuzzPurple, Modifier.weight(1f))
        }
        if (record == null) {
          Text("No record for this day yet. Tap here to add one.", style = MaterialTheme.typography.bodyMedium)
        } else {
          Text(
            "Cash " + money(record.cash) + "  |  Transfer " + money(record.transfer),
            style = MaterialTheme.typography.bodyMedium,
          )
          if (record.status == "draft" && record.remitted == 0.0) {
            Text("Remitted: not entered yet", style = MaterialTheme.typography.bodyMedium)
          } else {
            val note = remitNote(sales - spent, remitted)
            Text(
              "Remitted vs net: " + note.first,
              style = MaterialTheme.typography.labelLarge,
              color = if (note.second) BuzzGreen else MaterialTheme.colorScheme.error,
            )
          }
          if (record.lines.isNotEmpty()) {
            AppCard(modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = BuzzGold)
                  Text("Items Sold", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                  Text("Product", modifier = Modifier.weight(2f), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("Qty", modifier = Modifier.weight(0.7f), fontSize = 12.sp, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("Amount", modifier = Modifier.weight(1.3f), fontSize = 12.sp, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                record.lines.forEach { l ->
                  Row(modifier = Modifier.fillMaxWidth()) {
                    Text(l.name, modifier = Modifier.weight(2f))
                    Text(l.qty.toString(), modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                    Text(money(l.price * l.qty), modifier = Modifier.weight(1.3f), textAlign = TextAlign.End)
                  }
                }
              }
            }
          }
          if (record.expenses.isNotEmpty()) {
            AppCard(modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionHeader("\u2212", BuzzGold, "Expenses")
                record.expenses.forEach { e ->
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(e.desc, modifier = Modifier.weight(1f))
                    Text(money(e.amount))
                  }
                }
              }
            }
          }
        }
        Text(
          "Tap anywhere here to edit. Swipe left or right to change the day.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary,
        )
      }
    }

    if (listDays.isNotEmpty()) {
      item { Text("All Days", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
    }
    items(listDays) { d ->
      AppCard(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onSelect(d.date) },
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(d.date, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            StatusBadge("Submitted", BuzzGreen)
          }
          Row(modifier = Modifier.fillMaxWidth()) {
            MiniStat("Sales", money(d.sales), Modifier.weight(1f))
            MiniStat("Expenses", money(d.spent), Modifier.weight(1f))
            MiniStat("Net", money(d.sales - d.spent), Modifier.weight(1f))
            MiniStat("Remitted", money(d.remitted), Modifier.weight(1f))
          }
        }
      }
    }
  }
}

@Composable
fun ReportsTab(days: List<DayRecord>) {
  var period by remember { mutableStateOf("week") }
  var anchor by remember { mutableStateOf(todayString()) }
  val today = todayString()
  val range = periodRange(period, anchor)
  val inRange = days.filter { it.date >= range.first && it.date <= range.second }.sortedBy { it.date }
  val sales = inRange.sumOf { it.sales }
  val spent = inRange.sumOf { it.spent }
  val context = LocalContext.current
  var showExport by remember { mutableStateOf(false) }
  var pendingCsv by remember { mutableStateOf("") }
  val saveLauncher = rememberLauncherForActivityResult(
    ActivityResultContracts.CreateDocument("text/csv"),
  ) { uri ->
    if (uri != null) {
      try {
        context.contentResolver.openOutputStream(uri)?.use { out ->
          out.write(pendingCsv.toByteArray(Charsets.UTF_8))
        }
        Toast.makeText(context, "File saved", Toast.LENGTH_SHORT).show()
      } catch (e: Exception) {
        Toast.makeText(context, "Couldn't save the file", Toast.LENGTH_LONG).show()
      }
    }
  }

  val totals = HashMap<String, Pair<Long, Double>>()
  inRange.forEach { d ->
    d.lines.forEach { l ->
      val cur = totals[l.name] ?: Pair(0L, 0.0)
      totals[l.name] = Pair(cur.first + l.qty, cur.second + l.price * l.qty)
    }
  }
  val top = totals.entries.sortedByDescending { it.value.first }.take(10)

  val startDate = parseDate(range.first)
  val endDate = parseDate(range.second)
  val label = if (startDate == null || endDate == null) {
    range.first + " to " + range.second
  } else if (period == "week") {
    val f = SimpleDateFormat("d MMM yyyy", Locale.US)
    f.format(startDate) + " \u2013 " + f.format(endDate)
  } else {
    SimpleDateFormat("MMMM yyyy", Locale.US).format(startDate)
  }

  if (showExport) {
    val title = "Buzz Biz report"
    AlertDialog(
      onDismissRequest = { showExport = false },
      title = { Text(if (period == "week") "Export this week" else "Export this month") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(label, style = MaterialTheme.typography.bodyMedium)
          OutlinedButton(
            onClick = {
              pendingCsv = buildCsv(title, label, inRange)
              showExport = false
              saveLauncher.launch("buzz-biz-" + period + "-" + range.first + ".csv")
            },
            modifier = Modifier.fillMaxWidth(),
          ) { Text("Save as spreadsheet (CSV)") }
          OutlinedButton(
            onClick = {
              showExport = false
              val intent = Intent(Intent.ACTION_SEND)
              intent.type = "text/plain"
              intent.putExtra(Intent.EXTRA_TEXT, buildShareText(title, label, inRange))
              context.startActivity(Intent.createChooser(intent, "Share report"))
            },
            modifier = Modifier.fillMaxWidth(),
          ) { Text("Share as text") }
        }
      },
      confirmButton = {},
      dismissButton = { TextButton(onClick = { showExport = false }) { Text("Cancel") } },
    )
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (period == "week") {
          Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Weekly") }
          OutlinedButton(
            onClick = { period = "month"; anchor = todayString() },
            modifier = Modifier.weight(1f),
          ) { Text("Monthly") }
        } else {
          OutlinedButton(
            onClick = { period = "week"; anchor = todayString() },
            modifier = Modifier.weight(1f),
          ) { Text("Weekly") }
          Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Monthly") }
        }
      }
    }
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        TextButton(onClick = { anchor = shiftPeriod(period, anchor, -1) }) { Text("Previous") }
        Text(label, style = MaterialTheme.typography.titleMedium)
        TextButton(
          enabled = range.second < today,
          onClick = { anchor = shiftPeriod(period, anchor, 1) },
        ) { Text("Next") }
      }
    }
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          StatTile("Total Sales", money(sales), "\u20A6", BuzzBlue, Modifier.weight(1f))
          StatTile("Expenses", money(spent), "\u2212", BuzzGold, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          StatTile("Net Sales", money(sales - spent), "=", BuzzGreen, Modifier.weight(1f))
          StatTile("Total Remitted", money(inRange.sumOf { it.remitted }), "\u2192", BuzzPurple, Modifier.weight(1f))
        }
        Text(
          "Cash " + money(inRange.sumOf { it.cash }) + "  |  Transfer " + money(inRange.sumOf { it.transfer }) +
            "  |  " + inRange.size + " day(s)",
          style = MaterialTheme.typography.bodySmall,
        )
        OutlinedButton(onClick = { showExport = true }, modifier = Modifier.fillMaxWidth()) {
          Text(if (period == "week") "Export this week" else "Export this month")
        }
      }
    }
    if (top.isNotEmpty()) {
      item { Text("Top selling items", style = MaterialTheme.typography.titleMedium) }
      items(top) { e ->
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(e.key, modifier = Modifier.weight(1f))
            Text(e.value.first.toString() + " sold  |  " + money(e.value.second))
          }
        }
      }
    }
    if (inRange.isNotEmpty()) {
      item { Text("Day by day", style = MaterialTheme.typography.titleMedium) }
      items(inRange) { d ->
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(d.date)
            Text(money(d.sales) + " - " + money(d.spent) + " = " + money(d.sales - d.spent))
          }
        }
      }
    } else {
      item { Text("No records in this period.") }
    }
  }
}

@Composable
fun ItemsTab(catalog: List<Item>, onEdit: (Item) -> Unit, onMaster: () -> Unit) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          "Items staff can sell. Stock goes down automatically when a day is submitted.",
          style = MaterialTheme.typography.bodyMedium,
        )
        OutlinedButton(onClick = onMaster, modifier = Modifier.fillMaxWidth()) {
          Text("Master list and CSV upload")
        }
      }
    }
    if (catalog.isEmpty()) item { Text("No items yet. Open the master list to upload a CSV, or tap + to add one.") }
    items(catalog) { it2 ->
      AppCard(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onEdit(it2) },
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(it2.name, style = MaterialTheme.typography.titleMedium)
            if (it2.price == 0.0) {
              Text("Tap to set price", color = MaterialTheme.colorScheme.error)
            } else {
              Text(money(it2.price) + " each")
            }
          }
          Column(horizontalAlignment = Alignment.End) {
            Text("Store: " + it2.stock, style = MaterialTheme.typography.titleMedium)
            Text("Stock: " + it2.vault, style = MaterialTheme.typography.bodySmall)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MasterPickerScreen(
  catalog: List<Item>,
  categories: List<Pair<String, List<String>>>,
  hiddenCount: Int,
  onAdd: (List<String>) -> Unit,
  onAddMaster: (String, String) -> Unit,
  onImportRows: (List<CsvRow>) -> Unit,
  onRemoveMaster: (String) -> Unit,
  onRestore: () -> Unit,
  onBack: () -> Unit,
) {
  var query by remember { mutableStateOf("") }
  val selected = remember { mutableStateListOf<String>() }
  val existing = remember(catalog) { catalog.map { it.name.trim().lowercase() }.toSet() }
  var showAdd by remember { mutableStateOf(false) }
  var removeTarget by remember { mutableStateOf<String?>(null) }
  var newName by remember { mutableStateOf("") }
  var newCategory by remember { mutableStateOf("") }
  var pendingRows by remember { mutableStateOf<List<CsvRow>?>(null) }
  val context = LocalContext.current
  val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
    if (uri != null) {
      try {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
        val rows = parseItemsCsv(text)
        if (rows.isEmpty()) {
          Toast.makeText(context, "No items found in that file.", Toast.LENGTH_LONG).show()
        } else {
          pendingRows = rows
        }
      } catch (e: Exception) {
        Toast.makeText(context, "Couldn't read that file.", Toast.LENGTH_LONG).show()
      }
    }
  }

  BackHandler { onBack() }

  val pending = pendingRows
  if (pending != null) {
    val known = categories.flatMap { it.second }.map { it.trim().lowercase() }.toSet()
    val fresh = pending
      .distinctBy { it.name.trim().lowercase() }
      .filter { it.name.trim().lowercase() !in known }
    val sections = fresh.map { if (it.category.isBlank()) "Custom items" else it.category }.distinct().size
    AlertDialog(
      onDismissRequest = { pendingRows = null },
      title = { Text("Import items") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Found " + pending.size + " rows: " + fresh.size + " new item(s) in " + sections + " section(s). " + (pending.size - fresh.size) + " already in your list or repeated, skipped.")
          Text(
            "They are added to your master list. Pick the ones you sell, then add them to your items.",
            style = MaterialTheme.typography.bodySmall,
          )
        }
      },
      confirmButton = {
        TextButton(
          enabled = fresh.isNotEmpty(),
          onClick = {
            onImportRows(fresh)
            pendingRows = null
          },
        ) { Text("Add " + fresh.size + " items") }
      },
      dismissButton = { TextButton(onClick = { pendingRows = null }) { Text("Cancel") } },
    )
  }

  if (showAdd) {
    AlertDialog(
      onDismissRequest = { showAdd = false },
      title = { Text("Add to master list") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = newName,
            onValueChange = { newName = it },
            label = { Text("Item name") },
            singleLine = true,
          )
          OutlinedTextField(
            value = newCategory,
            onValueChange = { newCategory = it },
            label = { Text("Section (optional)") },
            singleLine = true,
          )
          Text(
            "Leave the section empty to put it under Custom items.",
            style = MaterialTheme.typography.bodySmall,
          )
        }
      },
      confirmButton = {
        TextButton(
          enabled = newName.isNotBlank(),
          onClick = {
            onAddMaster(newName.trim(), newCategory.trim())
            newName = ""
            newCategory = ""
            showAdd = false
          },
        ) { Text("Add") }
      },
      dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } },
    )
  }

  val toRemove = removeTarget
  if (toRemove != null) {
    AlertDialog(
      onDismissRequest = { removeTarget = null },
      title = { Text("Remove from master list?") },
      text = { Text(toRemove + " will no longer be suggested. Items already on your item list stay.") },
      confirmButton = {
        TextButton(onClick = {
          selected.remove(toRemove)
          onRemoveMaster(toRemove)
          removeTarget = null
        }) { Text("Remove") }
      },
      dismissButton = { TextButton(onClick = { removeTarget = null }) { Text("Cancel") } },
    )
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Master list") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
    bottomBar = {
      Button(
        enabled = selected.isNotEmpty(),
        onClick = { onAdd(selected.toList()) },
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
      ) {
        Text("Add " + selected.size + " selected to my items")
      }
    },
  ) { padding ->
    Column(
      modifier = Modifier
        .padding(padding)
        .padding(horizontal = 16.dp)
        .fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        label = { Text("Search items") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(onClick = { csvPicker.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
          Text("Upload CSV")
        }
        OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.weight(1f)) {
          Text("New item")
        }
      }
      if (hiddenCount > 0) {
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) {
          Text("Restore removed ($hiddenCount)")
        }
      }
      if (categories.isEmpty()) {
        Text("Your master list is empty. Upload a CSV file for your type of business, or add items one by one.")
      }
      Text(
        "CSV columns: name (required), category, price, stock. The first row can be a header.",
        style = MaterialTheme.typography.bodySmall,
      )
      Text(
        "Tick what you sell, then add. Tap the bin to remove an item from this list.",
        style = MaterialTheme.typography.bodySmall,
      )
      LazyColumn(modifier = Modifier.fillMaxSize()) {
        categories.forEach { entry ->
          val cat = entry.first
          val shown = entry.second.filter { query.isBlank() || it.contains(query.trim(), ignoreCase = true) }
          if (shown.isNotEmpty()) {
            item(key = "h:" + cat) {
              Text(
                cat,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
              )
            }
            items(shown, key = { cat + "|" + it }) { n ->
              val already = n.lowercase() in existing
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable(enabled = !already) {
                    if (n in selected) selected.remove(n) else selected.add(n)
                  },
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Checkbox(
                  checked = already || n in selected,
                  enabled = !already,
                  onCheckedChange = { checked ->
                    if (checked) {
                      if (n !in selected) selected.add(n)
                    } else {
                      selected.remove(n)
                    }
                  },
                )
                Text(
                  if (already) n + " (already added)" else n,
                  modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { removeTarget = n }) {
                  Icon(Icons.Default.Delete, contentDescription = "Remove from master list")
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ItemDialog(
  item: Item,
  catalog: List<Item>,
  masterNames: List<String>,
  onSave: (String, Double, Long, Long) -> Unit,
  onDelete: () -> Unit,
  onDismiss: () -> Unit,
) {
  val isNew = item.id.isEmpty()
  var vault by remember { mutableStateOf(if (isNew) "" else item.vault.toString()) }
  var name by remember { mutableStateOf(item.name) }
  var price by remember { mutableStateOf(if (isNew) "" else trimNum(item.price)) }
  var stock by remember { mutableStateOf(if (isNew) "" else item.stock.toString()) }
  var confirmDelete by remember { mutableStateOf(false) }

  if (confirmDelete) {
    AlertDialog(
      onDismissRequest = { confirmDelete = false },
      title = { Text("Delete this item?") },
      text = { Text("Past day records keep their sales, but this item will no longer be listed.") },
      confirmButton = { TextButton(onClick = onDelete) { Text("Delete") } },
      dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
    )
  } else {
    AlertDialog(
      onDismissRequest = onDismiss,
      title = { Text(if (isNew) "New item" else "Edit item") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            singleLine = true,
          )
          if (isNew && name.trim().length >= 2) {
            val taken = catalog.map { it.name.trim().lowercase() }.toSet()
            val suggestions = masterNames
              .filter {
                it.contains(name.trim(), ignoreCase = true) &&
                  !it.equals(name.trim(), ignoreCase = true) &&
                  it.lowercase() !in taken
              }
              .take(5)
            suggestions.forEach { sug ->
              TextButton(
                onClick = { name = sug },
                colors = ButtonDefaults.textButtonColors(contentColor = suggestionColor()),
              ) { Text(sug) }
            }
          }
          OutlinedTextField(
            value = price,
            onValueChange = { price = it.filter { c -> c.isDigit() || c == '.' }.take(10) },
            label = { Text("Price (\u20A6)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          )
          OutlinedTextField(
            value = vault,
            onValueChange = { vault = it.filter { c -> c.isDigit() }.take(7) },
            label = { Text("Stock inventory (main stock)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          )
          OutlinedTextField(
            value = stock,
            onValueChange = { stock = it.filter { c -> c.isDigit() }.take(7) },
            label = { Text("Store inventory (used by sales)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          )
        }
      },
      confirmButton = {
        TextButton(
          enabled = name.isNotBlank() && price.toDoubleOrNull() != null,
          onClick = {
            onSave(
              name.trim(),
              price.toDouble(),
              stock.toLongOrNull() ?: 0L,
              vault.toLongOrNull() ?: 0L,
            )
          },
        ) { Text("Save") }
      },
      dismissButton = {
        Row {
          if (!isNew) TextButton(onClick = { confirmDelete = true }) { Text("Delete") }
          TextButton(onClick = onDismiss) { Text("Cancel") }
        }
      },
    )
  }
}

// ---------------------------------------------------------------- daily record editor

class EditRow(
  initialName: String,
  initialQty: String,
  val legacyId: String = "",
  val legacyPrice: Double = 0.0,
) : StaffRow() {
  val legacyName: String = initialName

  init {
    name = initialName
    qty = initialQty
  }
}

private fun buildEditRows(existing: DayRecord?): SnapshotStateList<EditRow> {
  val list = mutableStateListOf<EditRow>()
  existing?.lines?.filter { it.qty > 0L }?.forEach { l ->
    list.add(EditRow(l.name, l.qty.toString(), l.itemId, l.price))
  }
  if (list.isEmpty()) list.add(EditRow("", ""))
  return list
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayEditorScreen(
  initialDate: String,
  isManager: Boolean,
  catalog: List<Item>,
  days: List<DayRecord>,
  onSubmit: (String, DayRecord?, List<Line>, List<Expense>, Double, Double) -> Unit,
  onDelete: (String, DayRecord) -> Unit,
  onBack: () -> Unit,
) {
  var date by remember { mutableStateOf(initialDate) }
  var confirmDelete by remember { mutableStateOf(false) }
  val existing = days.firstOrNull { it.date == date }
  val rows = remember(date, existing?.date) { buildEditRows(existing) }
  val expenseStates = remember(date, existing?.date) {
    mutableStateListOf<ExpenseState>().apply {
      existing?.expenses?.forEach {
        add(ExpenseState(it.desc, if (it.amount == 0.0) "" else trimNum(it.amount)))
      }
    }
  }
  var cash by remember(date, existing?.date) {
    mutableStateOf(if ((existing?.cash ?: 0.0) > 0.0) trimNum(existing?.cash ?: 0.0) else "")
  }
  var transfer by remember(date, existing?.date) {
    mutableStateOf(if ((existing?.transfer ?: 0.0) > 0.0) trimNum(existing?.transfer ?: 0.0) else "")
  }
  var error by remember { mutableStateOf<String?>(null) }

  BackHandler { onBack() }

  fun findItem(name: String): Item? =
    catalog.firstOrNull { it.name.trim().equals(name.trim(), ignoreCase = true) }

  fun lineFor(r: EditRow): Line? {
    val q = r.qty.toLongOrNull() ?: 0L
    if (q <= 0L) return null
    val n = r.name.trim()
    if (r.legacyId.isNotEmpty() && n.equals(r.legacyName.trim(), ignoreCase = true)) {
      return Line(r.legacyId, r.legacyName, r.legacyPrice, q)
    }
    val item = findItem(n) ?: return null
    return Line(item.id, item.name, item.price, q)
  }

  fun currentLines(): List<Line> = rows.mapNotNull { lineFor(it) }

  fun currentExpenses(): List<Expense> = expenseStates.mapNotNull { e ->
    val a = e.amount.toDoubleOrNull() ?: 0.0
    if (a > 0.0) Expense(e.desc.trim().ifBlank { "Expense" }, a) else null
  }

  val cashValue = cash.toDoubleOrNull() ?: 0.0
  val transferValue = transfer.toDoubleOrNull() ?: 0.0

  fun problem(): String? {
    val used = HashSet<String>()
    var any = false
    for (r in rows) {
      val n = r.name.trim()
      val q = r.qty.toLongOrNull() ?: 0L
      if (n.isEmpty() && q == 0L) continue
      any = true
      if (q <= 0L) return "Enter a quantity for " + n + "."
      val line = lineFor(r)
        ?: return "\"" + n + "\" isn't on the item list. Pick one of the suggestions."
      if (!used.add(line.itemId)) return line.name + " is listed twice. Put the quantity in one row."
      val item = catalog.firstOrNull { it.id == line.itemId }
      val oldQ = if (existing?.status == "submitted") {
        existing.lines.firstOrNull { it.itemId == line.itemId }?.qty ?: 0L
      } else {
        0L
      }
      if (item != null && q - oldQ > item.stock) {
        return line.name + ": only " + item.stock + " left in the store."
      }
    }
    val hasExpense = expenseStates.any { (it.amount.toDoubleOrNull() ?: 0.0) > 0.0 }
    if (!any && !hasExpense && cashValue <= 0.0 && transferValue <= 0.0) {
      return "Add at least one item sold, expense or remittance."
    }
    return null
  }

  if (confirmDelete && existing != null) {
    AlertDialog(
      onDismissRequest = { confirmDelete = false },
      title = { Text("Delete the record for $date?") },
      text = { Text("The record is removed and its items go back into stock. Staff can then submit that day again.") },
      confirmButton = {
        TextButton(onClick = {
          confirmDelete = false
          onDelete(date, existing)
          onBack()
        }) { Text("Delete") }
      },
      dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
    )
  }

  val linesNow = currentLines()
  val salesTotal = linesNow.sumOf { it.price * it.qty }
  val spentTotal = expenseStates.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
  val remittedTotal = cashValue + transferValue
  val note = remitNote(salesTotal - spentTotal, remittedTotal)

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Daily record") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          if (isManager && existing != null) {
            IconButton(onClick = { confirmDelete = true }) {
              Icon(Icons.Default.Delete, contentDescription = "Delete record")
            }
          }
        },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .padding(padding)
        .padding(horizontal = 16.dp)
        .fillMaxSize()
        .imePadding(),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = { date = shiftDate(date, -1); error = null }) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous day")
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(date, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (existing != null && existing.status == "draft") {
              StatusBadge("In progress", BuzzGold)
            }
          }
          IconButton(
            enabled = date < todayString(),
            onClick = { date = shiftDate(date, 1); error = null },
          ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next day")
          }
        }
      }

      item {
        ItemRowsCard(
          rows = rows,
          suggestionsFor = { r ->
            val typed = r.name.trim()
            val er = r as? EditRow
            val isLegacyName = er != null && er.legacyId.isNotEmpty() &&
              typed.equals(er.legacyName.trim(), ignoreCase = true)
            if (typed.isNotEmpty() && findItem(typed) == null && !isLegacyName) {
              catalog.filter { it.name.contains(typed, ignoreCase = true) }.take(5)
            } else {
              emptyList()
            }
          },
          onRemove = { r -> rows.removeAll { it === r } },
          onAdd = { rows.add(EditRow("", "")) },
          hint = if (catalog.isEmpty()) "No items yet. Add items on the Items tab first." else null,
        )
      }
      item { ExpensesCard(expenseStates, spentTotal) }
      item {
        RemittedCard(
          cash = cash,
          onCash = { cash = it },
          transfer = transfer,
          onTransfer = { transfer = it },
          total = remittedTotal,
        )
      }

      item {
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Sales")
              Text(money(salesTotal))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Expenses")
              Text(money(spentTotal))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Net", fontWeight = FontWeight.Bold)
              Text(money(salesTotal - spentTotal), fontWeight = FontWeight.Bold)
            }
            Text(
              "Remitted vs net: " + note.first,
              color = if (note.second) BuzzGreen else MaterialTheme.colorScheme.error,
            )
          }
        }
      }
      item {
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
      }
      item {
        Button(
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          shape = RoundedCornerShape(14.dp),
          onClick = {
            val p = problem()
            if (p != null) {
              error = p
            } else {
              onSubmit(date, existing, currentLines(), currentExpenses(), cashValue, transferValue)
              onBack()
            }
          },
        ) { Text("Save Record") }
      }
      item { Text("") }
    }
  }
}

// ---------------------------------------------------------------- settings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  email: String,
  role: String,
  bizName: String,
  code: String,
  staffJoined: Boolean,
  dark: Boolean,
  onDarkChange: (Boolean) -> Unit,
  onRemoveStaff: () -> Unit,
  onOpenLog: () -> Unit,
  onDeleteBusiness: () -> Unit,
  onSignOut: () -> Unit,
  onBack: () -> Unit,
) {
  val context = LocalContext.current
  var confirmDeleteBiz by remember { mutableStateOf(false) }
  var typedName by remember { mutableStateOf("") }
  var confirmSignOut by remember { mutableStateOf(false) }
  var confirmRemove by remember { mutableStateOf(false) }

  BackHandler { onBack() }

  if (confirmSignOut) {
    AlertDialog(
      onDismissRequest = { confirmSignOut = false },
      title = { Text("Sign out?") },
      text = { Text("You'll need your email and password to sign in again.") },
      confirmButton = {
        TextButton(onClick = {
          confirmSignOut = false
          onSignOut()
        }) { Text("Sign out") }
      },
      dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } },
    )
  }
  if (confirmDeleteBiz) {
    AlertDialog(
      onDismissRequest = { confirmDeleteBiz = false; typedName = "" },
      title = { Text("Delete " + bizName + "?") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("This permanently deletes all items, daily records, inventory, requests and the activity log, for you and your staff. It can't be undone. Export your reports first if you want a copy.")
          OutlinedTextField(
            value = typedName,
            onValueChange = { typedName = it },
            placeholder = { Text("Type \"" + bizName + "\" to confirm") },
            singleLine = true,
          )
        }
      },
      confirmButton = {
        TextButton(
          enabled = typedName.trim().equals(bizName.trim(), ignoreCase = true),
          onClick = {
            confirmDeleteBiz = false
            typedName = ""
            onDeleteBusiness()
          },
        ) { Text("Delete", color = MaterialTheme.colorScheme.error) }
      },
      dismissButton = { TextButton(onClick = { confirmDeleteBiz = false; typedName = "" }) { Text("Cancel") } },
    )
  }
  if (confirmRemove) {
    AlertDialog(
      onDismissRequest = { confirmRemove = false },
      title = { Text("Remove staff?") },
      text = { Text("The staff member loses access immediately. The staff spot opens up again for a new join.") },
      confirmButton = {
        TextButton(onClick = {
          confirmRemove = false
          onRemoveStaff()
        }) { Text("Remove") }
      },
      dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel") } },
    )
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Settings") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { padding ->
    Column(
      modifier = Modifier
        .padding(padding)
        .padding(20.dp)
        .fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text("Business: $bizName", style = MaterialTheme.typography.titleMedium)
      if (email.isNotBlank()) Text("Signed in as $email (" + role + ")")

      if (role == "manager") {
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Staff join code", style = MaterialTheme.typography.labelLarge)
            Text(code, style = MaterialTheme.typography.headlineSmall)
            Text(if (staffJoined) "A staff member has joined." else "The staff spot is open.")
            OutlinedButton(
              onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Join code", code))
                Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
              },
              modifier = Modifier.fillMaxWidth(),
            ) { Text("Copy code") }
            if (staffJoined) {
              OutlinedButton(
                onClick = { confirmRemove = true },
                modifier = Modifier.fillMaxWidth(),
              ) { Text("Remove staff") }
            }
          }
        }
      }

      if (role == "manager") {
        OutlinedButton(onClick = onOpenLog, modifier = Modifier.fillMaxWidth()) {
          Text("Activity log")
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Dark mode", style = MaterialTheme.typography.titleMedium)
        Switch(checked = dark, onCheckedChange = onDarkChange)
      }
      Button(onClick = { confirmSignOut = true }, modifier = Modifier.fillMaxWidth()) {
        Text("Sign out")
      }

      if (role == "manager") {
        Spacer(modifier = Modifier.height(12.dp))
        Text("Danger zone", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(
          onClick = { confirmDeleteBiz = true },
          modifier = Modifier.fillMaxWidth(),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
        ) { Text("Delete business", color = MaterialTheme.colorScheme.error) }
        Text(
          "Permanently deletes this business and all its records.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}
