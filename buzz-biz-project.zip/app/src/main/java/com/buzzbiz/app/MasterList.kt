package com.buzzbiz.app

// Buzz Biz ships with an empty master list. Each business builds its own
// by uploading a CSV file or adding items one by one.
object MasterList {
  val categories: List<Pair<String, List<String>>> = emptyList()

  val allNames: List<String> = categories.flatMap { it.second }.distinct()
}
