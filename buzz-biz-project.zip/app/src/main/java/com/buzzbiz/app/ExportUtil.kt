package com.buzzbiz.app

fun csvEscape(s: String): String =
  if (s.contains(',') || s.contains('"') || s.contains('\n')) {
    "\"" + s.replace("\"", "\"\"") + "\""
  } else {
    s
  }

fun remitNote(net: Double, remitted: Double): Pair<String, Boolean> {
  val diff = Math.round((remitted - net) * 100.0) / 100.0
  return when {
    diff == 0.0 -> Pair("Matches net", true)
    diff < 0.0 -> Pair("Short by " + money(-diff), false)
    else -> Pair("Over by " + money(diff), false)
  }
}

private fun itemTotals(days: List<DayRecord>): List<Triple<String, Long, Double>> {
  val map = LinkedHashMap<String, Pair<Long, Double>>()
  days.forEach { d ->
    d.lines.forEach { l ->
      val cur = map[l.name] ?: Pair(0L, 0.0)
      map[l.name] = Pair(cur.first + l.qty, cur.second + l.price * l.qty)
    }
  }
  return map.entries
    .sortedByDescending { it.value.first }
    .map { Triple(it.key, it.value.first, it.value.second) }
}

fun buildCsv(title: String, label: String, days: List<DayRecord>): String {
  val sb = StringBuilder()
  sb.append("\uFEFF")
  sb.append(csvEscape(title)).append("\n")
  sb.append("Period,").append(csvEscape(label)).append("\n\n")

  sb.append("Daily summary (NGN)\n")
  sb.append("Date,Sales,Expenses,Net,Cash,Transfer,Total remitted\n")
  days.forEach { d ->
    sb.append(d.date).append(',')
      .append(trimNum(d.sales)).append(',')
      .append(trimNum(d.spent)).append(',')
      .append(trimNum(d.sales - d.spent)).append(',')
      .append(trimNum(d.cash)).append(',')
      .append(trimNum(d.transfer)).append(',')
      .append(trimNum(d.remitted)).append('\n')
  }
  val sales = days.sumOf { it.sales }
  val spent = days.sumOf { it.spent }
  sb.append("Total,")
    .append(trimNum(sales)).append(',')
    .append(trimNum(spent)).append(',')
    .append(trimNum(sales - spent)).append(',')
    .append(trimNum(days.sumOf { it.cash })).append(',')
    .append(trimNum(days.sumOf { it.transfer })).append(',')
    .append(trimNum(days.sumOf { it.remitted })).append("\n\n")

  sb.append("Items sold\n")
  sb.append("Item,Quantity,Sales (NGN)\n")
  itemTotals(days).forEach { t ->
    sb.append(csvEscape(t.first)).append(',').append(t.second).append(',').append(trimNum(t.third)).append('\n')
  }
  sb.append('\n')

  sb.append("Expenses (NGN)\n")
  sb.append("Date,Description,Amount\n")
  days.forEach { d ->
    d.expenses.forEach { e ->
      sb.append(d.date).append(',').append(csvEscape(e.desc)).append(',').append(trimNum(e.amount)).append('\n')
    }
  }
  return sb.toString()
}

fun buildShareText(title: String, label: String, days: List<DayRecord>): String {
  val sb = StringBuilder()
  sb.append(title).append('\n').append(label).append("\n\n")
  val sales = days.sumOf { it.sales }
  val spent = days.sumOf { it.spent }
  sb.append("Sales: ").append(money(sales)).append('\n')
  sb.append("Expenses: ").append(money(spent)).append('\n')
  sb.append("Net: ").append(money(sales - spent)).append('\n')
  sb.append("Remitted: ").append(money(days.sumOf { it.remitted }))
    .append(" (Cash ").append(money(days.sumOf { it.cash }))
    .append(", Transfer ").append(money(days.sumOf { it.transfer })).append(")\n\n")

  sb.append("Day by day\n")
  days.forEach { d ->
    sb.append(d.date).append(": sales ").append(money(d.sales))
      .append(", expenses ").append(money(d.spent))
      .append(", net ").append(money(d.sales - d.spent))
      .append(", cash ").append(money(d.cash))
      .append(", transfer ").append(money(d.transfer)).append('\n')
  }

  val totals = itemTotals(days)
  if (totals.isNotEmpty()) {
    sb.append("\nItems sold\n")
    totals.forEach { t ->
      sb.append(t.first).append(": ").append(t.second).append(" sold, ").append(money(t.third)).append('\n')
    }
  }
  return sb.toString()
}
