package com.buzzbiz.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------- theme

val BuzzGold = Color(0xFFE5A93C)
val BuzzGreen = Color(0xFF3DBE6C)
val BuzzBlue = Color(0xFF2F80FF)
val BuzzPurple = Color(0xFFA78BFA)

val BuzzDarkScheme = darkColorScheme(
  primary = Color(0xFF2F80FF),
  onPrimary = Color.White,
  primaryContainer = Color(0xFF1B3A6B),
  onPrimaryContainer = Color(0xFFD6E4FF),
  secondary = Color(0xFFE5A93C),
  onSecondary = Color(0xFF241800),
  tertiary = Color(0xFFE5A93C),
  background = Color(0xFF0A0D14),
  onBackground = Color(0xFFF2F4F8),
  surface = Color(0xFF131824),
  onSurface = Color(0xFFF2F4F8),
  surfaceVariant = Color(0xFF1B2232),
  onSurfaceVariant = Color(0xFFA9B2C3),
  surfaceContainerLowest = Color(0xFF0A0D14),
  surfaceContainerLow = Color(0xFF0F131D),
  surfaceContainer = Color(0xFF0F131D),
  surfaceContainerHigh = Color(0xFF171D2B),
  surfaceContainerHighest = Color(0xFF1B2232),
  outline = Color(0xFF3A4458),
  outlineVariant = Color(0xFF283044),
  error = Color(0xFFFF6B6B),
  onError = Color(0xFF2B0000),
)

val BuzzLightScheme = lightColorScheme(
  primary = Color(0xFF1F6FEB),
  onPrimary = Color.White,
  secondary = Color(0xFFB7791F),
  tertiary = Color(0xFFB7791F),
  background = Color(0xFFF6F7FA),
  surface = Color(0xFFFFFFFF),
  outlineVariant = Color(0xFFD9DEE8),
)

// ---------------------------------------------------------------- basic pieces

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    content = content,
  )
}

@Composable
fun GlyphBadge(glyph: String, tint: Color) {
  Box(
    modifier = Modifier
      .size(32.dp)
      .clip(CircleShape)
      .background(tint.copy(alpha = 0.18f)),
    contentAlignment = Alignment.Center,
  ) {
    Text(glyph, color = tint, fontWeight = FontWeight.Bold, fontSize = 16.sp)
  }
}

@Composable
fun SectionHeader(glyph: String, tint: Color, title: String) {
  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    GlyphBadge(glyph, tint)
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
fun StatTile(label: String, value: String, glyph: String, tint: Color, modifier: Modifier = Modifier) {
  AppCard(modifier = modifier) {
    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlyphBadge(glyph, tint)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
      Text(
        value,
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
      )
    }
  }
}

@Composable
fun StatusBadge(text: String, tint: Color) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(50))
      .background(tint.copy(alpha = 0.2f))
      .padding(horizontal = 10.dp, vertical = 3.dp),
  ) {
    Text(text, color = tint, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
fun SuccessBanner(text: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(BuzzGreen.copy(alpha = 0.16f))
      .border(1.dp, BuzzGreen.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
      .padding(horizontal = 14.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Icon(Icons.Default.Check, contentDescription = null, tint = BuzzGreen)
    Text(text, color = BuzzGreen, fontWeight = FontWeight.Medium)
  }
}

@Composable
fun TotalRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .background(MaterialTheme.colorScheme.surfaceVariant)
      .padding(horizontal = 12.dp, vertical = 10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(label, style = MaterialTheme.typography.bodyMedium)
    Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
  }
}

@Composable
fun QtyStepper(value: String, onChange: (String) -> Unit) {
  val current = value.toLongOrNull() ?: 0L
  Row(
    modifier = Modifier
      .height(40.dp)
      .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp)),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    IconButton(
      onClick = { onChange((current - 1L).coerceAtLeast(0L).toString()) },
      modifier = Modifier.size(34.dp),
    ) { Text("\u2212", fontSize = 18.sp) }
    BasicTextField(
      value = value,
      onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(6)) },
      singleLine = true,
      textStyle = TextStyle(
        color = MaterialTheme.colorScheme.onSurface,
        fontSize = 16.sp,
        textAlign = TextAlign.Center,
      ),
      cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
      modifier = Modifier.width(38.dp),
    )
    IconButton(
      onClick = { onChange((current + 1L).coerceAtMost(999999L).toString()) },
      modifier = Modifier.size(34.dp),
    ) { Text("+", fontSize = 18.sp) }
  }
}

// ---------------------------------------------------------------- shared form cards

@Composable
fun ItemRowsCard(
  rows: List<StaffRow>,
  suggestionsFor: (StaffRow) -> List<Item>,
  onRemove: (StaffRow) -> Unit,
  onAdd: () -> Unit,
  hint: String?,
) {
  AppCard(modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = BuzzGold)
        Text("Items Sold", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
      }
      if (hint != null) {
        Text(hint, style = MaterialTheme.typography.bodySmall)
      }
      rows.forEach { row ->
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            OutlinedTextField(
              value = row.name,
              onValueChange = { row.name = it },
              label = { Text("Item name") },
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
            QtyStepper(value = row.qty, onChange = { row.qty = it })
            IconButton(onClick = { onRemove(row) }, modifier = Modifier.size(40.dp)) {
              Icon(Icons.Default.Delete, contentDescription = "Remove item", tint = MaterialTheme.colorScheme.error)
            }
          }
          suggestionsFor(row).forEach { sug ->
            TextButton(
              onClick = { row.name = sug.name },
              colors = ButtonDefaults.textButtonColors(contentColor = suggestionColor()),
            ) {
              Text(sug.name + " (" + sug.stock + " in stock)")
            }
          }
        }
      }
      OutlinedButton(
        onClick = onAdd,
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, BuzzGold),
      ) {
        Icon(Icons.Default.Add, contentDescription = null)
        Text("  Add Item")
      }
    }
  }
}

@Composable
fun ExpensesCard(expenseStates: SnapshotStateList<ExpenseState>, total: Double) {
  AppCard(modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      SectionHeader("\u20A6", BuzzGold, "Expenses")
      expenseStates.forEach { e ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          OutlinedTextField(
            value = e.desc,
            onValueChange = { e.desc = it },
            label = { Text("What for") },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = e.amount,
            onValueChange = { e.amount = it.filter { c -> c.isDigit() || c == '.' }.take(10) },
            label = { Text("Amount") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.width(104.dp),
          )
          IconButton(onClick = { expenseStates.remove(e) }, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "Remove expense", tint = MaterialTheme.colorScheme.error)
          }
        }
      }
      OutlinedButton(
        onClick = { expenseStates.add(ExpenseState("", "")) },
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, BuzzGold),
      ) {
        Icon(Icons.Default.Add, contentDescription = null)
        Text("  Add Expense")
      }
      TotalRow("Total Expenses", money(total))
    }
  }
}

@Composable
fun RemittedCard(
  cash: String,
  onCash: (String) -> Unit,
  transfer: String,
  onTransfer: (String) -> Unit,
  total: Double,
) {
  AppCard(modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      SectionHeader("\u2192", BuzzPurple, "Remitted")
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = cash,
          onValueChange = { onCash(it.filter { c -> c.isDigit() || c == '.' }.take(10)) },
          label = { Text("Cash") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          modifier = Modifier.weight(1f),
        )
        OutlinedTextField(
          value = transfer,
          onValueChange = { onTransfer(it.filter { c -> c.isDigit() || c == '.' }.take(10)) },
          label = { Text("Transfer") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          modifier = Modifier.weight(1f),
        )
      }
      TotalRow("Total Remitted", money(total))
    }
  }
}


// White on the dark theme, blue on the light theme.
@Composable
fun suggestionColor(): Color =
  if (MaterialTheme.colorScheme.background.luminance() < 0.5f) Color.White else MaterialTheme.colorScheme.primary

@Composable
fun GoldButton(text: String, enabled: Boolean, onClick: () -> Unit) {
  val brush = if (enabled) {
    Brush.horizontalGradient(listOf(Color(0xFFFFD66B), Color(0xFFE0A21E)))
  } else {
    Brush.horizontalGradient(listOf(Color(0xFF3A4458), Color(0xFF3A4458)))
  }
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(54.dp)
      .clip(RoundedCornerShape(16.dp))
      .background(brush)
      .clickable(enabled = enabled, onClick = onClick),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text,
      color = if (enabled) Color(0xFF1A1204) else Color(0xFF8A93A6),
      fontWeight = FontWeight.Bold,
      fontSize = 16.sp,
    )
  }
}
