package com.buzzbiz.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- models

data class StockRequest(
  val id: String,
  val status: String,
  val byEmail: String,
  val createdMillis: Long,
  val lines: List<Line>,
)

fun DocumentSnapshot.toRequest(): StockRequest {
  val ts = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
  val lines = (get("lines") as? List<*>)?.mapNotNull { raw ->
    val m = raw as? Map<*, *> ?: return@mapNotNull null
    Line(
      itemId = m["itemId"] as? String ?: "",
      name = m["name"] as? String ?: "",
      price = 0.0,
      qty = (m["qty"] as? Number)?.toLong() ?: 0L,
    )
  } ?: emptyList()
  return StockRequest(
    id = id,
    status = getString("status").orEmpty(),
    byEmail = getString("byEmail").orEmpty(),
    createdMillis = ts?.toDate()?.time ?: 0L,
    lines = lines,
  )
}

data class MasterDoc(
  val id: String,
  val kind: String,
  val name: String,
  val category: String,
  val price: Double? = null,
  val stock: Long? = null,
)

fun DocumentSnapshot.toMasterDoc(): MasterDoc =
  MasterDoc(
    id = id,
    kind = getString("kind").orEmpty(),
    name = getString("name").orEmpty(),
    category = getString("category").orEmpty(),
    price = getDouble("price"),
    stock = getLong("stock"),
  )

class MasterView(
  val categories: List<Pair<String, List<String>>>,
  val customIds: Map<String, String>,
  val hiddenIds: List<String>,
  val names: List<String>,
  val defaults: Map<String, Pair<Double, Long>>,
)

fun buildMasterView(docs: List<MasterDoc>): MasterView {
  val hidden = docs.filter { it.kind == "hide" }.map { it.name.trim().lowercase() }.toSet()
  val hiddenIds = docs.filter { it.kind == "hide" }.map { it.id }
  val customIds = HashMap<String, String>()
  val adds = docs.filter { it.kind == "add" && it.name.isNotBlank() }
  adds.forEach { customIds[it.name.trim().lowercase()] = it.id }
  val defaults = HashMap<String, Pair<Double, Long>>()
  adds.forEach {
    if (it.price != null || it.stock != null) {
      defaults[it.name.trim().lowercase()] = Pair(it.price ?: 0.0, it.stock ?: 0L)
    }
  }

  val cats = ArrayList<Pair<String, List<String>>>()
  MasterList.categories.forEach { entry ->
    val kept = entry.second.filter { it.lowercase() !in hidden }
    if (kept.isNotEmpty()) cats.add(Pair(entry.first, kept))
  }
  val grouped = adds.groupBy { if (it.category.isBlank()) "Custom items" else it.category.trim() }
  grouped.forEach { entry ->
    cats.add(Pair(entry.key, entry.value.map { it.name.trim() }.distinct()))
  }
  val names = cats.flatMap { it.second }.distinct()
  return MasterView(cats, customIds, hiddenIds, names, defaults)
}

private fun statusText(status: String): String = when (status) {
  "pending" -> "Waiting for approval"
  "approved" -> "Approved"
  "rejected" -> "Rejected"
  else -> status
}

private fun requestTime(ms: Long): String =
  if (ms > 0L) SimpleDateFormat("d MMM, HH:mm", Locale.US).format(Date(ms)) else "just now"

// ---------------------------------------------------------------- staff inventory page

@Composable
private fun RequestCard(r: StockRequest) {
  AppCard(modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
      Text(
        statusText(r.status) + "  |  " + requestTime(r.createdMillis),
        style = MaterialTheme.typography.titleSmall,
      )
      r.lines.forEach { l ->
        Text(l.name + " \u00D7 " + l.qty, style = MaterialTheme.typography.bodyMedium)
      }
    }
  }
}


@Composable
fun StaffInventoryScreen(
  catalog: List<Item>,
  requests: List<StockRequest>,
  onSubmit: (List<Line>) -> Unit,
) {
  val rows = remember { mutableStateListOf(StaffRow()) }
  var error by remember { mutableStateOf<String?>(null) }
  var confirmSubmit by remember { mutableStateOf(false) }
  val openRequests = requests.filter { it.status == "pending" }
  val decidedRequests = requests.filter { it.status != "pending" }.take(10)

  fun findItem(name: String): Item? =
    catalog.firstOrNull { it.name.trim().equals(name.trim(), ignoreCase = true) }

  fun problem(): String? {
    val used = HashSet<String>()
    var any = false
    for (r in rows) {
      val n = r.name.trim()
      val q = r.qty.toLongOrNull() ?: 0L
      if (n.isEmpty() && q == 0L) continue
      any = true
      val item = findItem(n)
        ?: return "\"" + n + "\" isn't on the item list. Pick one of the suggestions."
      if (q <= 0L) return "Enter a quantity for " + item.name + "."
      if (!used.add(item.id)) return item.name + " is listed twice. Put the quantity in one row."
    }
    if (!any) return "Add at least one received item."
    return null
  }

  fun currentLines(): List<Line> = rows.mapNotNull { r ->
    val item = findItem(r.name)
    val q = r.qty.toLongOrNull() ?: 0L
    if (item != null && q > 0L) Line(item.id, item.name, 0.0, q) else null
  }

  if (confirmSubmit) {
    AlertDialog(
      onDismissRequest = { confirmSubmit = false },
      title = { Text("Submit received items?") },
      text = { Text("The store inventory goes up now. The manager will approve or reject this.") },
      confirmButton = {
        TextButton(onClick = {
          confirmSubmit = false
          onSubmit(currentLines())
          rows.clear()
          rows.add(StaffRow())
          error = null
        }) { Text("Submit") }
      },
      dismissButton = { TextButton(onClick = { confirmSubmit = false }) { Text("Cancel") } },
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .imePadding(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item { Text("Received items", style = MaterialTheme.typography.titleMedium) }
    item {
      Text(
        "Add items delivered to the store. The manager must approve them.",
        style = MaterialTheme.typography.bodySmall,
      )
    }
    if (catalog.isEmpty()) {
      item { Text("No items are available yet. Ask the manager to add items first.") }
    }
    items(rows) { row ->
      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = row.name,
            onValueChange = { row.name = it },
            label = { Text("Item name") },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = row.qty,
            onValueChange = { row.qty = it.filter { c -> c.isDigit() }.take(6) },
            label = { Text("Qty") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.width(90.dp),
          )
          IconButton(onClick = { rows.remove(row) }) {
            Icon(Icons.Default.Close, contentDescription = "Remove item")
          }
        }
        val typed = row.name.trim()
        if (typed.isNotEmpty() && findItem(typed) == null) {
          catalog
            .filter { it.name.contains(typed, ignoreCase = true) }
            .take(5)
            .forEach { suggestion ->
              TextButton(
                onClick = { row.name = suggestion.name },
                colors = ButtonDefaults.textButtonColors(contentColor = suggestionColor()),
              ) { Text(suggestion.name) }
            }
        }
      }
    }
    item {
      OutlinedButton(
        onClick = { rows.add(StaffRow()) },
        modifier = Modifier.fillMaxWidth(),
      ) { Text("Add item") }
    }
    item {
      error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
    item {
      Button(
        modifier = Modifier.fillMaxWidth(),
        onClick = {
          val p = problem()
          if (p != null) {
            error = p
          } else {
            error = null
            confirmSubmit = true
          }
        },
      ) { Text("Submit received items") }
    }

    item {
      Text(
        "Waiting for approval",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 12.dp),
      )
    }
    if (openRequests.isEmpty()) {
      item { Text("No open requests.") }
    }
    items(openRequests) { r -> RequestCard(r) }

    item {
      Text(
        "Store inventory",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 12.dp),
      )
    }
    if (catalog.isEmpty()) {
      item { Text("Nothing listed yet.") }
    }
    items(catalog) { it2 ->
      AppCard(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(it2.name, modifier = Modifier.weight(1f))
          Text(it2.stock.toString(), style = MaterialTheme.typography.titleMedium)
        }
      }
    }

    if (decidedRequests.isNotEmpty()) {
      item {
        Text(
          "Approved and past requests",
          style = MaterialTheme.typography.titleMedium,
          modifier = Modifier.padding(top = 12.dp),
        )
      }
      items(decidedRequests) { r -> RequestCard(r) }
    }
    item { Text("") }
  }
}

// ---------------------------------------------------------------- manager inventory tab

@Composable
fun ManagerInventoryTab(
  catalog: List<Item>,
  requests: List<StockRequest>,
  onApprove: (StockRequest) -> Unit,
  onReject: (StockRequest) -> Unit,
  onMove: (Item, Long) -> Unit,
) {
  var rejectTarget by remember { mutableStateOf<StockRequest?>(null) }
  var moveTarget by remember { mutableStateOf<Item?>(null) }
  var moveQty by remember { mutableStateOf("") }

  val pending = requests.filter { it.status == "pending" }
  val decided = requests.filter { it.status != "pending" }.take(10)

  val toReject = rejectTarget
  if (toReject != null) {
    AlertDialog(
      onDismissRequest = { rejectTarget = null },
      title = { Text("Reject these items?") },
      text = { Text("The items are taken back out of the store inventory.") },
      confirmButton = {
        TextButton(onClick = {
          onReject(toReject)
          rejectTarget = null
        }) { Text("Reject") }
      },
      dismissButton = { TextButton(onClick = { rejectTarget = null }) { Text("Cancel") } },
    )
  }

  val toMove = moveTarget
  if (toMove != null) {
    val qty = moveQty.toLongOrNull() ?: 0L
    AlertDialog(
      onDismissRequest = { moveTarget = null },
      title = { Text("Move " + toMove.name + " to store") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Available in stock inventory: " + toMove.vault)
          OutlinedTextField(
            value = moveQty,
            onValueChange = { moveQty = it.filter { c -> c.isDigit() }.take(7) },
            label = { Text("Quantity") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          )
        }
      },
      confirmButton = {
        TextButton(
          enabled = qty > 0L && qty <= toMove.vault,
          onClick = {
            onMove(toMove, qty)
            moveTarget = null
          },
        ) { Text("Move") }
      },
      dismissButton = { TextButton(onClick = { moveTarget = null }) { Text("Cancel") } },
    )
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item { Text("Pending requests", style = MaterialTheme.typography.titleMedium) }
    if (pending.isEmpty()) {
      item { Text("No requests waiting for approval.") }
    }
    items(pending) { r ->
      AppCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            "Received items  |  " + requestTime(r.createdMillis),
            style = MaterialTheme.typography.titleSmall,
          )
          if (r.byEmail.isNotBlank()) {
            Text(r.byEmail, style = MaterialTheme.typography.bodySmall)
          }
          r.lines.forEach { l ->
            val item = catalog.firstOrNull { it.id == l.itemId }
            val short = item == null || item.vault < l.qty
            Text(
              l.name + " \u00D7 " + l.qty + (if (short) "  (not enough in stock inventory)" else ""),
              style = MaterialTheme.typography.bodyMedium,
              color = if (short) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onApprove(r) }) { Text("Approve") }
            OutlinedButton(onClick = { rejectTarget = r }) { Text("Reject") }
          }
        }
      }
    }

    item {
      Text(
        "Inventory",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 12.dp),
      )
    }
    item {
      Text(
        "Stock inventory is your main stock. Store inventory is what sales deduct from.",
        style = MaterialTheme.typography.bodySmall,
      )
    }
    if (catalog.isEmpty()) {
      item { Text("No items yet. Add items on the Items tab first.") }
    }
    items(catalog) { it2 ->
      AppCard(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(it2.name, style = MaterialTheme.typography.titleMedium)
            Text("Stock: " + it2.vault + "  |  Store: " + it2.stock, style = MaterialTheme.typography.bodyMedium)
          }
          OutlinedButton(
            onClick = {
              moveQty = ""
              moveTarget = it2
            },
          ) { Text("Move to store") }
        }
      }
    }

    if (decided.isNotEmpty()) {
      item {
        Text(
          "Recent decisions",
          style = MaterialTheme.typography.titleMedium,
          modifier = Modifier.padding(top = 12.dp),
        )
      }
      items(decided) { r ->
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(statusText(r.status) + "  |  " + requestTime(r.createdMillis), style = MaterialTheme.typography.titleSmall)
            r.lines.forEach { l ->
              Text(l.name + " \u00D7 " + l.qty, style = MaterialTheme.typography.bodyMedium)
            }
          }
        }
      }
    }
    item { Text("") }
  }
}
