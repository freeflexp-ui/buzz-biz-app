package com.buzzbiz.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- activity log model

data class LogEntry(
  val id: String,
  val atMillis: Long,
  val action: String,
  val date: String,
  val role: String,
  val email: String,
  val summary: String,
  val detail: String,
)

fun DocumentSnapshot.toLogEntry(): LogEntry {
  val ts = getTimestamp("at", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
  return LogEntry(
    id = id,
    atMillis = ts?.toDate()?.time ?: 0L,
    action = getString("action").orEmpty(),
    date = getString("date").orEmpty(),
    role = getString("byRole").orEmpty(),
    email = getString("byEmail").orEmpty(),
    summary = getString("summary").orEmpty(),
    detail = getString("detail").orEmpty(),
  )
}

fun describeRecord(
  lines: List<Line>,
  exps: List<Expense>,
  cash: Double = 0.0,
  transfer: Double = 0.0,
): String {
  val sb = StringBuilder()
  if (lines.isEmpty()) {
    sb.append("No items")
  } else {
    sb.append(lines.joinToString(", ") { it.name + " \u00D7 " + it.qty })
  }
  sb.append(" | Sales ").append(money(lines.sumOf { it.price * it.qty }))
  if (exps.isNotEmpty()) {
    sb.append(" | Expenses: ").append(exps.joinToString(", ") { it.desc + " " + money(it.amount) })
  }
  if (cash > 0.0 || transfer > 0.0) {
    sb.append(" | Cash ").append(money(cash)).append(", Transfer ").append(money(transfer))
  }
  return sb.toString()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityLogScreen(
  logs: List<LogEntry>,
  canClear: Boolean,
  clearNote: String,
  onClear: () -> Unit,
  onShare: () -> Unit,
  onBack: () -> Unit,
) {
  var confirmClear by remember { mutableStateOf(false) }
  BackHandler { onBack() }

  if (confirmClear) {
    AlertDialog(
      onDismissRequest = { confirmClear = false },
      title = { Text("Clear the activity log?") },
      text = {
        Text("This permanently removes every log entry and the history of approved or rejected inventory receipts (receipts still waiting for approval stay). It can't be undone. Your daily records, totals, stock and reports are not affected. You can only clear once a month, so tap Share log first if you want a copy.")
      },
      confirmButton = {
        TextButton(onClick = {
          confirmClear = false
          onClear()
        }) { Text("Clear log") }
      },
      dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
    )
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Activity log") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .padding(padding)
        .padding(horizontal = 16.dp)
        .fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedButton(
              onClick = onShare,
              enabled = logs.isNotEmpty(),
              modifier = Modifier.weight(1f),
            ) { Text("Share log") }
            Button(
              onClick = { confirmClear = true },
              enabled = canClear,
              modifier = Modifier.weight(1f),
            ) { Text("Clear log") }
          }
          if (clearNote.isNotBlank()) {
            Text(clearNote, style = MaterialTheme.typography.bodySmall)
          }
        }
      }
      if (logs.isEmpty()) {
        item { Text("No activity yet. Submissions, edits, deletions and inventory changes will appear here.") }
      }
      items(logs) { entry ->
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(entry.summary, style = MaterialTheme.typography.titleMedium)
            val whenText = if (entry.atMillis > 0L) {
              SimpleDateFormat("d MMM yyyy, HH:mm", Locale.US).format(Date(entry.atMillis))
            } else {
              "just now"
            }
            val who = if (entry.role == "manager") "Manager" else "Staff"
            Text(
              who + (if (entry.email.isNotBlank()) " (" + entry.email + ")" else "") + "  |  " + whenText,
              style = MaterialTheme.typography.bodySmall,
            )
            if (entry.detail.isNotBlank()) {
              Text(entry.detail, style = MaterialTheme.typography.bodyMedium)
            }
          }
        }
      }
    }
  }
}

// ---------------------------------------------------------------- staff daily record page

open class StaffRow {
  var name by mutableStateOf("")
  var qty by mutableStateOf("")
}

@Composable
fun StaffRecordScreen(
  catalog: List<Item>,
  days: List<DayRecord>,
  onSave: (String, DayRecord?, List<Line>, List<Expense>, Double, Double, Boolean) -> Unit,
) {
  val today = todayString()
  val yesterday = shiftDate(today, -1)
  val yesterdaySubmitted = days.firstOrNull { it.date == yesterday }?.status == "submitted"
  val date = if (yesterdaySubmitted) today else yesterday
  val canSubmit = !yesterdaySubmitted
  val existing = days.firstOrNull { it.date == date }
  val locked = existing?.status == "submitted"
  val hasRecord = existing != null

  val rows = remember(date, hasRecord) {
    mutableStateListOf<StaffRow>().apply {
      existing?.lines?.filter { it.qty > 0L }?.forEach { l ->
        val r = StaffRow()
        r.name = l.name
        r.qty = l.qty.toString()
        add(r)
      }
      if (isEmpty()) add(StaffRow())
    }
  }
  val expenseStates = remember(date, hasRecord) {
    mutableStateListOf<ExpenseState>().apply {
      existing?.expenses?.forEach { add(ExpenseState(it.desc, trimNum(it.amount))) }
    }
  }
  var cash by remember(date, hasRecord) {
    mutableStateOf(if ((existing?.cash ?: 0.0) > 0.0) trimNum(existing?.cash ?: 0.0) else "")
  }
  var transfer by remember(date, hasRecord) {
    mutableStateOf(if ((existing?.transfer ?: 0.0) > 0.0) trimNum(existing?.transfer ?: 0.0) else "")
  }
  var error by remember { mutableStateOf<String?>(null) }
  var savedNote by remember(date) { mutableStateOf(false) }
  var confirmSubmit by remember { mutableStateOf(false) }

  fun findItem(name: String): Item? =
    catalog.firstOrNull { it.name.trim().equals(name.trim(), ignoreCase = true) }

  fun problem(forSubmit: Boolean): String? {
    val used = HashSet<String>()
    var any = false
    for (r in rows) {
      val n = r.name.trim()
      val q = r.qty.toLongOrNull() ?: 0L
      if (n.isEmpty() && q == 0L) continue
      any = true
      val item = findItem(n)
        ?: return "\"" + n + "\" isn't on the item list. Pick one of the suggestions."
      if (q <= 0L) return "Enter a quantity for " + item.name + "."
      if (!used.add(item.id)) return item.name + " is listed twice. Put the quantity in one row."
      if (forSubmit && q > item.stock) return item.name + ": only " + item.stock + " left in stock."
    }
    val hasExpense = expenseStates.any { (it.amount.toDoubleOrNull() ?: 0.0) > 0.0 }
    val hasRemit = (cash.toDoubleOrNull() ?: 0.0) > 0.0 || (transfer.toDoubleOrNull() ?: 0.0) > 0.0
    if (!any && !hasExpense && !hasRemit) return "Add at least one item sold, expense or remittance."
    return null
  }

  fun currentLines(): List<Line> = rows.mapNotNull { r ->
    val item = findItem(r.name)
    val q = r.qty.toLongOrNull() ?: 0L
    if (item != null && q > 0L) Line(item.id, item.name, item.price, q) else null
  }

  fun currentExpenses(): List<Expense> = expenseStates.mapNotNull { e ->
    val a = e.amount.toDoubleOrNull() ?: 0.0
    if (a > 0.0) Expense(e.desc.trim().ifBlank { "Expense" }, a) else null
  }

  if (confirmSubmit) {
    AlertDialog(
      onDismissRequest = { confirmSubmit = false },
      title = { Text("Submit record for $date?") },
      text = { Text("After submitting, you can't change it. Only the manager can fix it.") },
      confirmButton = {
        TextButton(onClick = {
          confirmSubmit = false
          onSave(
            date,
            existing,
            currentLines(),
            currentExpenses(),
            cash.toDoubleOrNull() ?: 0.0,
            transfer.toDoubleOrNull() ?: 0.0,
            true,
          )
        }) { Text("Submit") }
      },
      dismissButton = { TextButton(onClick = { confirmSubmit = false }) { Text("Cancel") } },
    )
  }

  val spentTotal = expenseStates.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
  val remittedTotal = (cash.toDoubleOrNull() ?: 0.0) + (transfer.toDoubleOrNull() ?: 0.0)
  val submittedDays = days.filter { it.status != "draft" }
  val buttonShape = RoundedCornerShape(14.dp)

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .imePadding(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    if (!canSubmit) {
      item { SuccessBanner("Yesterday's record is submitted") }
    }
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Column {
          Text(
            (if (canSubmit) "Yesterday \u2022 " else "Today \u2022 ") + date,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          if (!canSubmit) {
            Text(
              "Save your progress as you go. The manager sees it live. You can submit it tomorrow.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }

    if (locked) {
      item {
        AppCard(modifier = Modifier.fillMaxWidth()) {
          Text(
            "This record is already submitted and locked. If something is wrong, ask the manager to fix it.",
            modifier = Modifier.padding(14.dp),
          )
        }
      }
    } else {
      item {
        ItemRowsCard(
          rows = rows,
          suggestionsFor = { r ->
            val typed = r.name.trim()
            if (typed.isNotEmpty() && findItem(typed) == null) {
              catalog.filter { it.name.contains(typed, ignoreCase = true) }.take(5)
            } else {
              emptyList()
            }
          },
          onRemove = { r -> rows.remove(r) },
          onAdd = { rows.add(StaffRow()) },
          hint = if (catalog.isEmpty()) "No items are available yet. Ask the manager to add items first." else null,
        )
      }
      item { ExpensesCard(expenseStates, spentTotal) }
      item {
        RemittedCard(
          cash = cash,
          onCash = { cash = it },
          transfer = transfer,
          onTransfer = { transfer = it },
          total = remittedTotal,
        )
      }
      item {
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
      }
      item {
        if (savedNote) {
          Text("Progress saved. The manager can see it.", color = BuzzGreen)
        }
      }
      if (canSubmit) {
        item {
          Button(
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp),
            shape = buttonShape,
            onClick = {
              val p = problem(true)
              if (p != null) {
                error = p
              } else {
                error = null
                confirmSubmit = true
              }
            },
          ) { Text("Submit Record") }
        }
      } else {
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            OutlinedButton(
              modifier = Modifier
                .weight(1f)
                .height(52.dp),
              shape = buttonShape,
              onClick = {
                val p = problem(false)
                if (p != null) {
                  error = p
                  savedNote = false
                } else {
                  error = null
                  onSave(
                    date,
                    existing,
                    currentLines(),
                    currentExpenses(),
                    cash.toDoubleOrNull() ?: 0.0,
                    transfer.toDoubleOrNull() ?: 0.0,
                    false,
                  )
                  savedNote = true
                }
              },
            ) { Text("Save Progress") }
            Button(
              enabled = false,
              onClick = {},
              shape = buttonShape,
              modifier = Modifier
                .weight(1f)
                .height(52.dp),
            ) { Text("Submit Record") }
          }
        }
        item {
          Text(
            "Submitting opens on " + shiftDate(date, 1),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }

    item {
      Text(
        "Last 5 submitted records",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp),
      )
    }
    if (submittedDays.isEmpty()) {
      item { Text("Nothing submitted yet.") }
    }
    items(submittedDays.take(5)) { d ->
      AppCard(modifier = Modifier.fillMaxWidth()) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(d.date, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            StatusBadge("Submitted", BuzzGreen)
          }
          if (d.lines.isNotEmpty()) {
            Text("Items sold", style = MaterialTheme.typography.labelLarge)
            d.lines.forEach { l ->
              Text(l.name + " \u00D7 " + l.qty, style = MaterialTheme.typography.bodyMedium)
            }
          }
          if (d.expenses.isNotEmpty()) {
            Text("Expenses", style = MaterialTheme.typography.labelLarge)
            d.expenses.forEach { e ->
              Text(e.desc + "  -  " + money(e.amount), style = MaterialTheme.typography.bodyMedium)
            }
          }
          if (d.remitted > 0.0) {
            Text("Remitted", style = MaterialTheme.typography.labelLarge)
            Text(
              "Cash " + money(d.cash) + "  |  Transfer " + money(d.transfer),
              style = MaterialTheme.typography.bodyMedium,
            )
          }
        }
      }
    }
    item { Text("") }
  }
}
